import java.util.Base64;

public class JavaBase64BasicExample {
	public static void main(String[] args) {
		 // Getting encoder  
		Base64.Encoder encoder = Base64.getEncoder();
		// Creating byte array  
		byte bytearray[] = {1,2};
		// encoding byte array  
		byte bytearray2[] =encoder.encode(bytearray);
		System.out.println("Encoded byte array: "+bytearray2);
		//simple
		String st = encoder.encodeToString("javaTpoint".getBytes());
		System.out.println("Encoded string: "+st);
		 Base64.Decoder decoder = Base64.getDecoder();
		// Decoding string  
        String dStr = new String(decoder.decode(st));  
        System.out.println("Decoded string: "+dStr); 
        
        //url
        // Getting encoder  
        Base64.Encoder encoder1 = Base64.getUrlEncoder();  
        // Encoding URL  
        String eStr = encoder1.encodeToString("http://www.javatpoint.com/java-tutorial/".getBytes());  
        System.out.println("Encoded URL: "+eStr);  
        // Getting decoder  
        Base64.Decoder decoder1 = Base64.getUrlDecoder();  
        // Decoding URl  
        String dStr1 = new String(decoder.decode(eStr));  
        System.out.println("Decoded URL: "+dStr1);
        //MIME Encoding and Decoding
        
        // Getting MIME encoder  
        Base64.Encoder encoder2 = Base64.getMimeEncoder();  
        String message = "Hello, \nYou are informed regarding your inconsistency of work";  
        String eStr1 = encoder2.encodeToString(message.getBytes());  
        System.out.println("Encoded MIME message: "+eStr);  
          
        // Getting MIME decoder  
        Base64.Decoder decoder2 = Base64.getMimeDecoder();  
        // Decoding MIME encoded message  
        String dStr2 = new String(decoder2.decode(eStr));  
        System.out.println("Decoded message: "+dStr2);   
	}
}
