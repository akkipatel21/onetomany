package com.Maulik.manager;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.Maulik.Repository.RegisterRepository;
import com.Maulik.dto.Register;
import com.Maulik.model.createRegisterRequest;

@Controller
public class RegisterManager 
{
	@Autowired
	RegisterRepository registerrepository;

	

	public void Register_user(createRegisterRequest form) 
	{	
		Register register=new Register();
		
		register.setFirstname(form.getFirstname());
		register.setLastname(form.getLastname());
		register.setEmail(form.getEmail());
		register.setPassword(form.getPassword());
		register.setMobile(form.getMobile());
		
		registerrepository.save(register);
	}



	public List<Register> getallUser() 
	{
		return (List<Register>) registerrepository.findAll();
	}



	

	public void edit_user(createRegisterRequest form) {
		Register register=new Register();
		
		register.setId(form.getId());
		register.setFirstname(form.getFirstname());
		register.setLastname(form.getLastname());
		register.setEmail(form.getEmail());
		register.setPassword(form.getPassword());
		register.setMobile(form.getMobile());
		
		registerrepository.save(register);
	}



/*	public Register login_user(createRegisterRequest form) 
	{
		
		return registerrepository.login_user(form.getEmail(),form.getPassword());
	}
*/
	
}
