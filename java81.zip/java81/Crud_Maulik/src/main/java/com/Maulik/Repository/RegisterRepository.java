package com.Maulik.Repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.Maulik.dto.Register;

@Transactional
public interface RegisterRepository extends CrudRepository<Register, Long>
{

//	@Query("select u form Register u where u.email=:email AND u.password=:password")
//	public Register login_user(@Param("email") String email, @Param("password") String password);

	
}
