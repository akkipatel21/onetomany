package com.Maulik.controller;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.Maulik.Repository.RegisterRepository;
import com.Maulik.dto.Register;
import com.Maulik.model.createRegisterRequest;
import com.Maulik.services.RegisterServices;

@Controller
public class RegisterController 
{
	@Autowired
	private RegisterServices registerservices;
	
	@Autowired
	private RegisterRepository registerRepository;
	
	@RequestMapping("/index")
	public ModelAndView getCreateIndexView() 
	{
		ModelMap model = new ModelMap();
		model.addAttribute("Main_Page", "Main_Page");
		model.addAttribute("form", new createRegisterRequest());
		return new ModelAndView("index", model);
	}
	
	
	@RequestMapping("/register_here")
	public ModelAndView getCreateRegisterView() 
	{
		ModelMap model = new ModelMap();
		model.addAttribute("register_Page", "register_Page");
		model.addAttribute("form", new createRegisterRequest());
		return new ModelAndView("index", model);
	}

	@RequestMapping(value = "/register_user", method = RequestMethod.POST)
	public String RegisterUser(@ModelAttribute("form") @Valid createRegisterRequest form, BindingResult result) 
	{
		registerservices.Register_user(form);		
		return "redirect:/index";
	}
	
	
	
	@RequestMapping(value = "/get_user", method = RequestMethod.GET)
	public ModelAndView login_user_view(@ModelAttribute("form") @Valid createRegisterRequest form, HttpSession session ) 
	{
	
		ModelMap model = new ModelMap();
		model.addAttribute("users", "Users");
		model.addAttribute("user_list", registerservices.getallUser().getRegister_user());
		return new ModelAndView("index", model);
	}
	
	@RequestMapping(value = "/edit_user", method = RequestMethod.GET)
	public ModelAndView Edit_user_view(@ModelAttribute("form") @Valid createRegisterRequest form, HttpSession session ) 
	{
	
		Register reg=registerRepository.findOne(form.getId());
		
		ModelMap model = new ModelMap();
		model.addAttribute("edits_user", "Users_edit");
		model.addAttribute("id", reg.getId());
		model.addAttribute("form", reg);
		return new ModelAndView("index", model);
	}
	
	
	@RequestMapping(value = "/edit_user", method = RequestMethod.POST)
	public String edit_user_update(@ModelAttribute("form") @Valid createRegisterRequest form, BindingResult result) 
	{
		registerservices.edit_user(form);		
		return "redirect:/get_user";
	}

/*	@RequestMapping(value = "/login_user", method = RequestMethod.POST)
	public ModelAndView login_user_view(@ModelAttribute("form") @Valid createRegisterRequest form, BindingResult result) 
	{
	 Register r= registerservices.login_user(form);		
		
		if(r!=null)
		{
			ModelMap model = new ModelMap();
			model.addAttribute("Login_success", "Login_success");
			model.addAttribute("id", r.getId());
			model.addAttribute("email", r.getEmail());
			return new ModelAndView("index", model);
		}
		else
		{
			ModelMap model = new ModelMap();
			model.addAttribute("Login_fail", "Login_fail");
			return new ModelAndView("index", model);
		}
		
		
	}
	
*/	
	
}
