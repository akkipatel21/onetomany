package com.Maulik;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudMaulikApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudMaulikApplication.class, args);
	}
}
