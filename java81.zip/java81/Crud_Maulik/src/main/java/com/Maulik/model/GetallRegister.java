package com.Maulik.model;

import java.util.List;

import com.Maulik.dto.Register;

public class GetallRegister
{
	
	public List<Register> register_user;

	public List<Register> getRegister_user() {
		return register_user;
	}

	public void setRegister_user(List<Register> register_user) {
		this.register_user = register_user;
	}

	

}
