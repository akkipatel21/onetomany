import java.io.File;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class JavaStreamExample {

	public static void main(String[] args) throws UnknownHostException {
		/*List<Product> plist =new ArrayList<Product>();
		plist.add(new Product(1, "pratik", 3000f));
		plist.add(new Product(2, "viksah", 4000f));
		List<Float> pplist =plist.stream().filter(p->p.price>3000).map(p->p.price).collect(Collectors.toList());
		System.out.println(pplist);
		String myFile = "D:/desktop/esense_Db1/db_content";
		String myFile1 = "D:/pratDir";///simpleDb2/content
		if(!new File(myFile).exists()) {
			new File(myFile).mkdirs();
			System.out.println("folders is created "+(new File(myFile).mkdirs()));
		}
		if(!new File(myFile1).exists()) {
			new File(myFile1).mkdir();
			System.out.println("folder is created"+(new File(myFile1).mkdir()));
		}*/
		/*try {
	        InetAddress ipAddr = InetAddress.getByName("www.google.com"); 
	        if(!ipAddr.equals("")) {
	        	System.out.println("internet available ::::: ");
	        }else {
	        	System.out.println("internet available not ::::: ");
	        }
	        //You can replace it with your name
	            //return !ipAddr.equals("");

	        } catch (Exception e) {
	            //return false;
	        	System.out.println("internet available not ::::: ");
	    }*/
		"127.0.0.1".equals(InetAddress.getLocalHost().getHostAddress().toString());
		System.out.println("\"www.google.com\".equals(InetAddress.getLocalHost().getHostAddress().toString());"+"127.0.0.1".equals(InetAddress.getLocalHost().getHostAddress().toString()));
	}

}
