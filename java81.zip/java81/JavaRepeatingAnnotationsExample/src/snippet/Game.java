package snippet;

public @interface Game {

}
