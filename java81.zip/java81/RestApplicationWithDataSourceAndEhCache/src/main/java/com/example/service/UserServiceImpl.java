package com.example.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.repository.UserRepository;
import com.example.model.User;

@Service("userService")
@CacheConfig(cacheNames = "users")
public class UserServiceImpl implements UserService{
	private static Logger log = LoggerFactory.getLogger(UserServiceImpl.class);
	
	@Autowired
	UserRepository userRepo;
	
	@Cacheable(value="users")
	public List<User> findAllUsers() {
		System.out.println("fetchind method findAllUsers >>>>>>>>>>>>>>>>>>");
        return (List<User>) userRepo.findAll();
    }
     
	@Cacheable(value="users", key="{#id}")
    public User findById(long id) {
		System.out.println("fetchind method findById >>>>>>>>>>>>>>>>>>");
		log.info("Executing: " + this.getClass().getSimpleName() + ".findById(\"" + id + "\");");
        return userRepo.findOne(id);
    }
    
	@Cacheable(value="users", key="#name")
    public List<User> findUserByName(String userName) {
		System.out.println("fetchind method findUserByName >>>>>>>>>>>>>>>>>>");
		log.info("findUserByName: 1");
        return userRepo.findUser(userName);
    }
     
    public void saveUser(User user) {
    	System.out.println("fetchind method saveUser >>>>>>>>>>>>>>>>>>");
    	userRepo.save(user);
    }
    
    @CachePut(value="users", key="#id")
    public User updateUser(User user,long id) {
    	System.out.println("fetchind method updateUser >>>>>>>>>>>>>>>>>>");
    	log.info("updateUser: 1");
    	
    	User currentUser = userRepo.findOne(id);
    	currentUser.setAge(user.getAge());
    	currentUser.setName(user.getName());
    	currentUser.setSalary(user.getSalary());
    	userRepo.save(currentUser);
    	
    	return currentUser;
    }
    
    @CacheEvict(value = "users", key = "#id")
    public void deleteUserById(long id) {
    	System.out.println("fetchind method updateUser >>>>>>>>>>>>>>>>>>");
    	log.info("deleteUserById: 1");
    	User currentUser = userRepo.findOne(id);
    	userRepo.delete(currentUser);
    }
    	
}
