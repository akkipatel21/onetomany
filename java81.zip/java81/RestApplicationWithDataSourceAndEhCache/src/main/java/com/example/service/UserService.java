package com.example.service;

import java.util.List;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.example.model.User;

@Component

public interface UserService {
	//@Cacheable(value="users", key="#id")
	User findById(long id);
    
	//@Cacheable(value="users", key="#name")
    List<User> findUserByName(String userName);
    
    void saveUser(User user);
    
    //@CachePut(value="users", key="#id")
    User updateUser(User user, long id);
    
    @CacheEvict(value = "users", key = "#id")
    void deleteUserById(long id);
    
    //@Cacheable(value="users")
    List<User> findAllUsers();
    
    //List<User> updateAllUser(User user);
    
    
}
