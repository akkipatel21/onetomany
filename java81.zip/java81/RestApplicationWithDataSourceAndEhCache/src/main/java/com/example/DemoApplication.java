package com.example;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication
@EnableCaching
public class DemoApplication {
	private static Logger log = LoggerFactory.getLogger(DemoApplication.class);
	//@Autowired
    //private static CacheManager cacheManager;
	
	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
		
		log.info("Spring Boot Ehcache 2 Caching Example Configuration");
        //log.info("using cache manager: " + cacheManager.getClass().getName());
	}
	
}
