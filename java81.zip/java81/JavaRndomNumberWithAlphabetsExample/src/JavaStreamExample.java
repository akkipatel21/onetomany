import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class JavaStreamExample {

	private static final String key = "Bar12345Bar12345";
	public static void main(String[] args) throws Exception {
		/*List<Product> plist =new ArrayList<Product>();
		plist.add(new Product(1, "pratik", 3000f));
		plist.add(new Product(2, "viksah", 4000f));
		List<Float> pplist =plist.stream().filter(p->p.price>3000).map(p->p.price).collect(Collectors.toList());
		System.out.println(pplist);
		String myFile = "D:/desktop/esense_Db1/db_content";
		String myFile1 = "D:/pratDir";///simpleDb2/content
		if(!new File(myFile).exists()) {
			new File(myFile).mkdirs();
			System.out.println("folders is created "+(new File(myFile).mkdirs()));
		}
		if(!new File(myFile1).exists()) {
			new File(myFile1).mkdir();
			System.out.println("folder is created"+(new File(myFile1).mkdir()));
		}*/
		
		String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 18) { // length of the random string.
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
            salt.append(SALTCHARS.charAt(index));
        }
        String saltStr = salt.toString();
        System.out.println("saltStr :: "+saltStr);
        String srt = encrypt(saltStr,key);
        System.out.println("encrypt srt :: "+srt);
        String srt1 = decrypt(srt,key);
        System.out.println("decrypt srt :: "+srt1);
	}
	
	public static String encrypt(String strClearText,String strKey) throws Exception{
		String strData="";
		
		try {
			SecretKeySpec skeyspec=new SecretKeySpec(strKey.getBytes(),"Blowfish");
			Cipher cipher=Cipher.getInstance("Blowfish");
			cipher.init(Cipher.ENCRYPT_MODE, skeyspec);
			byte[] encrypted=cipher.doFinal(strClearText.getBytes());
			strData=new String(encrypted);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e);
		}
		return strData;
	}
	
	public static String decrypt(String strEncrypted,String strKey) throws Exception{
		String strData="";
		
		try {
			SecretKeySpec skeyspec=new SecretKeySpec(strKey.getBytes(),"Blowfish");
			Cipher cipher=Cipher.getInstance("Blowfish");
			cipher.init(Cipher.DECRYPT_MODE, skeyspec);
			byte[] decrypted=cipher.doFinal(strEncrypted.getBytes());
			strData=new String(decrypted);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e);
		}
		return strData;
	}

}

