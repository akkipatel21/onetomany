import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class JavaRandomStringGenerate {
	public static void main(String[] args) {
		
	}

}


