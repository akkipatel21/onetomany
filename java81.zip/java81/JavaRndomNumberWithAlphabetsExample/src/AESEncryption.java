import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

public class AESEncryption {

	private static final String key = "Bar12345Bar12345";
	/*public static void main(String[] args) throws Exception {
		List<Product> plist =new ArrayList<Product>();
		plist.add(new Product(1, "pratik", 3000f));
		plist.add(new Product(2, "viksah", 4000f));
		List<Float> pplist =plist.stream().filter(p->p.price>3000).map(p->p.price).collect(Collectors.toList());
		System.out.println(pplist);
		String myFile = "D:/desktop/esense_Db1/db_content";
		String myFile1 = "D:/pratDir";///simpleDb2/content
		if(!new File(myFile).exists()) {
			new File(myFile).mkdirs();
			System.out.println("folders is created "+(new File(myFile).mkdirs()));
		}
		if(!new File(myFile1).exists()) {
			new File(myFile1).mkdir();
			System.out.println("folder is created"+(new File(myFile1).mkdir()));
		}
		
		String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 18) { // length of the random string.
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
            salt.append(SALTCHARS.charAt(index));
        }
        String saltStr = salt.toString();
        System.out.println("saltStr :: "+saltStr);
        String srt = encrypt(saltStr,key);
        System.out.println("encrypt srt :: "+srt);
        String srt1 = decrypt(srt,key);
        System.out.println("decrypt srt :: "+srt1);
	}*/
	
		public static void main(String[] args) throws Exception {
		        //String plainText = "Hello World";
		        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		        StringBuilder salt = new StringBuilder();
		        Random rnd = new Random();
		        while (salt.length() < 18) { // length of the random string.
		            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
		            salt.append(SALTCHARS.charAt(index));
		        }
		        String plainText = salt.toString();
		        System.out.println("saltStr :: "+plainText);
		        SecretKey secKey = getSecretEncryptionKey();
		        byte[] cipherText = encryptText(plainText, secKey);
		        String decryptedText = decryptText(cipherText, secKey);
		        System.out.println("Original Text:" + plainText);
		        System.out.println("AES Key (Hex Form):"+bytesToHex(secKey.getEncoded()));
		        System.out.println("Encrypted Text (Hex Form):"+bytesToHex(cipherText));
		        System.out.println("Descrypted Text:"+decryptedText);
		    }
		public static SecretKey getSecretEncryptionKey() throws Exception{
			        KeyGenerator generator = KeyGenerator.getInstance("AES");
			        generator.init(128); // The AES key size in number of bits
			        SecretKey secKey = generator.generateKey();
			        return secKey;
			    }
		public static byte[] encryptText(String plainText,SecretKey secKey) throws Exception{
			        // AES defaults to AES/ECB/PKCS5Padding in Java 7
			        Cipher aesCipher = Cipher.getInstance("AES");
			        aesCipher.init(Cipher.ENCRYPT_MODE, secKey);
			        byte[] byteCipherText = aesCipher.doFinal(plainText.getBytes());
			        return byteCipherText;
			    }

		public static String decryptText(byte[] byteCipherText, SecretKey secKey) throws Exception {
			        // AES defaults to AES/ECB/PKCS5Padding in Java 7
			        Cipher aesCipher = Cipher.getInstance("AES");
			        aesCipher.init(Cipher.DECRYPT_MODE, secKey);
			        byte[] bytePlainText = aesCipher.doFinal(byteCipherText);
			        return new String(bytePlainText);
			    }
			    /**
			77
			     * Convert a binary byte array into readable hex form
			78
			     * @param hash
			79
			     * @return
			80
			     */
			    private static String  bytesToHex(byte[] hash) {
			        return DatatypeConverter.printHexBinary(hash);
			    }

	
	

}

