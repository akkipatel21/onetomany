package com.roufid.tutorial.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import com.roufid.tutorial.entity.Author;
@Transactional
public interface AuthorDao extends CrudRepository<Author, Integer> {

}
