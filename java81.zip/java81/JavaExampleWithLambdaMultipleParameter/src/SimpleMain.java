import java.util.ArrayList;
import java.util.List;

public class SimpleMain {

	public static void main(String[] args) {
		Operation o =(a,b)->(a+b);
		System.out.println(o.sum(10, 20));
		
		Operation o1 =(int a, int b)->{
			return (a+b);
		};
		System.out.println(o1.sum(30, 30));
		List<String> person = new ArrayList<String>();
		person.add("pratik");
		person.add("Maulik");
		person.add("Vikash");
		person.add("Juhi");
		person.add("Rutvik");
		
		person.forEach(
				(n)->System.out.println(n)
		);
	}

}
