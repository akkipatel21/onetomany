
public interface Operation {
public int sum(int a,int b);
}
