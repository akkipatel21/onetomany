package com.example.service;

import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.example.model.User;

public interface UserService {
	
	User findById(long id);
    
    List<User> findUserByName(String userName);
     
    void saveUser(User user);
     
    void updateUser(User user);
     
    void deleteUserById(long id);
 
    List<User> findAllUsers(); 
 
    /*List<User> findTopOneUserByName(String userName);
    List<User> findTopThreeUser(String userName);
    List<User> findByName();*/
    
}
