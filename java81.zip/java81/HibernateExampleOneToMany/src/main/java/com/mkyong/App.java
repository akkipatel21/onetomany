package com.mkyong;

import java.util.List;


import org.hibernate.*;
import org.hibernate.SessionFactory;

import com.mkyong.stock.Stock;
import com.mkyong.stock.StockDailyRecord;
import com.mkyong.util.HibernateUtil;

public class App {
	public static void main(String[] args) {
		System.out.println("START");
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		Stock stock = null;
		
        /*stock.setName("tata");
        session.merge(stock);*/
		
		stock = readStock("l&t");
		if(stock.getId() == null || stock.getId()==0){
			stock.setName("l&t");
	        session.save(stock);
	        
	        StockDailyRecord stockDailyRecords = new StockDailyRecord();
	        stockDailyRecords.setName("l&t pipe..new");
	        
	        stockDailyRecords.setStock(stock);
	        stock.getStockDailyRecords().add(stockDailyRecords);
	        session.save(stockDailyRecords);
		}else{
			StockDailyRecord stockDailyRecords = new StockDailyRecord();
	        stockDailyRecords.setName("l&t pipe..old");
	        
	        stockDailyRecords.setStock(stock);
	        session.save(stockDailyRecords);
		}
		session.getTransaction().commit();
		System.out.println("END OK");
	}
	
	private static Stock readStock(String nm) {
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		String hql = "FROM Stock WHERE name = '"+nm+"'";
		Query query = session.createQuery(hql);
		List results = query.list();
		Stock obj = null;
		if(results.size()==0){
			return new Stock();
		}else{
			obj = (Stock) results.get(0);
		}
		session.close();
		return obj;
	}
}
