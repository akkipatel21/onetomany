package com.example.service;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.repository.UserRepository;

import ch.qos.logback.core.net.SyslogOutputStream;

import com.example.model.User;

@Service("userService")
public class UserServiceImpl implements UserService{
	
	@Autowired
	UserRepository userRepo;
	
	//@CachePut(value="users")
	@Cacheable(value="users")
	public List<User> findAllUsers() {
		
        return (List<User>) userRepo.findAll();
    }
     
	//@Cacheable(value="users", key="#id")
	
	@Cacheable(value="users")
    public User findById(long id) {
        return userRepo.findOne(id);
    }
    
	@Cacheable(value="users", key="#name")
    public List<User> findUserByName(String userName) {
        return userRepo.findUser(userName);
    }
     
    public void saveUser(User user) {
    	userRepo.save(user);
    }
    
    @CachePut(value="users", key="#id")
    public User updateUser(User user,long id) {
    	User currentUser = userRepo.findOne(id);
    	currentUser.setAge(user.getAge());
    	currentUser.setName(user.getName());
    	currentUser.setSalary(user.getSalary());
    	userRepo.save(currentUser);
    	this.findAllUsers(currentUser);
    	return currentUser;
    }
    
    @Cacheable(value="users")
	public List<User> findAllUsers(User usercurrent) {
    	List<User> userlist = this.findAllUsers();
    	List<User> returnList = new ArrayList<>();
    	
    	System.out.println("userluist >>>>> "+userlist.size());
    	 userlist.stream().filter(new Predicate<User>() {

			@Override
			public boolean test(User t) {
				System.out.println("user >>>>> "+t);
				if(t != null && t.getId() == usercurrent.getId()) {
					returnList.add(usercurrent);
					return true;
				}else {
				returnList.add(t);
				return false;
				}
			}
    		
		}).collect(Collectors.toList()).get(0);
    	
    	 System.out.println("returnList >>>>> "+returnList);
    	
        return returnList;
    }
    
    @CacheEvict(value = "users", key = "#id")
    public void deleteUserById(long id) {
    	User currentUser = userRepo.findOne(id);
    	userRepo.delete(currentUser);
    }
    	
}
