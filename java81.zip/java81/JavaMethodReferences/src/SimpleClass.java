import java.util.function.BiFunction;

public class SimpleClass {
	public static void sayable(){
		System.out.println("HELLO JAVA");
	}
	public static int add(int a,int b) {
		return (a+b);
	}
	
	 public void saySomething(){  
	      System.out.println("Hello, this is non-static method.");  
	 }  

	public static void main(String[] args) {
		
		
		Simple s = SimpleClass::sayable;
		s.say();
		BiFunction<Integer, Integer, Integer> bf =SimpleClass :: add;
		int result =bf.apply(10, 15);
		System.out.println("result ::"+result);
		
		Simple s2 = new SimpleClass() ::saySomething;
		s2.say();
	}

}
