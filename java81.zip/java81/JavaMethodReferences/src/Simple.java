
public interface Simple {
	void say();
}
