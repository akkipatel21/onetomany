
public class SimpleMessage {
	public static void main(String[] args) {

		 MessageI hello = Message::new;  
	     hello.getMessage("Hello"); 
	}
}
