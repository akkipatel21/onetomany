
public interface MessageI {

	Message getMessage(String msg); 
}
