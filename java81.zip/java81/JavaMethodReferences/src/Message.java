
public class Message {
	public Message(String msg) {
		System.out.println(msg);
	}
}
