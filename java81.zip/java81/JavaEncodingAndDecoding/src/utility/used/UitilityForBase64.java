package utility.used;

import java.io.UnsupportedEncodingException;
import java.util.Base64;

public class UitilityForBase64 {
	public byte[] decodeMethod(String dec) throws UnsupportedEncodingException {
		
		
	    // Decode
	    byte[] base64decodedBytes = Base64.getDecoder().decode(dec);
		return base64decodedBytes;
	}
	public String encodeMethod(String enc ,String FormateType) throws UnsupportedEncodingException {
		String base64encodedString = Base64.getEncoder().encodeToString(enc.getBytes(FormateType));
        System.out.println("Base64 Encoded String (Basic) :" + base64encodedString);
		return base64encodedString;
		
	}
	
}
