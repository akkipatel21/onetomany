import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.Scanner;

import utility.used.UitilityForBase64;

public class JavaDecodingAndEncoding {

	public static void main(String[] args) throws UnsupportedEncodingException {
		 Scanner sc=new Scanner(System.in); 
		 UitilityForBase64 util = new UitilityForBase64();
		 
		 System.out.println("Enter your String");
	     //we can get input through user
		 //String enco ="";
		 String formateType = "utf-16";
	     String  name =sc.next();
	     if(name != "" && name != null) {
	    	//here call the encodeMethod with user parameter
	     String enco = util.encodeMethod(name,formateType);
	     }else {
	    	 System.out.println("Re Enter your String");
	    	 name=sc.next(); 
	     }
	     
	     byte[] decodedVal =new byte[200] ;
		 System.out.println("Enter your endode string");
	     //we can get input through user
	     String endodedString =sc.next();
	     
	     if(endodedString != "" && endodedString != null) {
		     //here call the decodeMethod with pass endoded code 
	      	 decodedVal =  util.decodeMethod(endodedString);
			 System.out.println("Original String: " + new String(decodedVal, formateType));
	    }else {
	    	 System.out.println("Re Enter your endode string");
		     //we can get input through user
		     endodedString =sc.next();
	     }
		 
		 sc.close(); 
	}

}
