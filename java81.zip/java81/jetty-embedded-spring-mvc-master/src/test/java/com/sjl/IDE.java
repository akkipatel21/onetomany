package com.sjl;

public class IDE {
	// This class is a place-holder used to identify whether the
	// web-server is running in an IDE where the test class hierarchy
	// is available or in "production" mode (test classes removed)
}
