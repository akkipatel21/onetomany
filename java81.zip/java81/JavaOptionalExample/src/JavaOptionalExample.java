import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class JavaOptionalExample {
	 public static void main(String[] args) {  
	        String[] str = new String[10];  
	        Optional<String> checkNull = Optional.ofNullable(str[5]);  
	        if(checkNull.isPresent()){  // check for value is present or not  
	            String lowercaseString = str[5].toLowerCase();  
	            System.out.print(lowercaseString);  
	        }else { 
	            System.out.println("string value is not present");
	        }
	 		

	        String[] str1 = new String[10];        
	        str1[5] = "JAVA OPTIONAL CLASS EXAMPLE";// Setting value for 5th index  
	        Optional<String> checkNull1 = Optional.ofNullable(str1[5]);  
	        if(checkNull1.isPresent()){  // It Checks, value is present or not  
	            String lowercaseString1 = str1[5].toLowerCase();  
	            System.out.print(lowercaseString1);  
	        }else { 
	            System.out.println("String value is not present");
	        }
	        List<Person> plist = new ArrayList<Person>();
	        plist.add(new Person("pratik"));
	        plist.add(new Person("joshi"));
	        plist.add(new Person("prex"));
	        
	        Long val =plist.stream().collect(Collectors.counting());
	        System.out.println("val ::"+val);
	        
	        List<String>  val1 =plist.stream().filter(p->p.name == "pratik").map(p->p.name).collect(Collectors.toList());
	        Long  val2 =plist.stream().filter(p->p.name == "pratik").map(p->p.name).collect(Collectors.counting());
	        System.out.println("val1 ::"+val1);
	        System.out.println("val2 ::"+val2);
			
			
	    }  
}
