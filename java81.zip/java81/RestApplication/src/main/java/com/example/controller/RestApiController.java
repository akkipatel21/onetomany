package com.example.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.example.model.User;
import com.example.service.UserService;
import com.example.util.CustomErrorType;

@RestController
@RequestMapping("/api")
public class RestApiController {

	public static final Logger logger = LoggerFactory.getLogger(RestApiController.class);

	@Autowired
	UserService userService; //Service which will do all data retrieval/manipulation work

	// -------------------Retrieve All Users---------------------------------------------

	@RequestMapping(value = "/user/", method = RequestMethod.GET)
	public List<User> listAllUsers() {
		logger.info("Fetching User List {}");
		List<User> users = userService.findAllUsers();
		if (users.isEmpty()) {
			return new ArrayList<User>();
		}
		return users;
	}

	// -------------------Retrieve Single User------------------------------------------

	@RequestMapping(value = "/user/{id}", method = RequestMethod.GET)
	public User getUser(@PathVariable("id") long id) {
		logger.info("Fetching User with id {}", id);
		User user = userService.findById(id);
		if (user == null) {
			logger.error("User with id {} not found.", id);
			return new User();
		}
		return user;
	}

	// -------------------Create a User-------------------------------------------

	@RequestMapping(value = "/user/", method = RequestMethod.POST)
	public String createUser(@RequestBody User user) {
		logger.info("Creating User : {}", user);
		String createVal ="";
		if (userService.isUserExist(user)) {
			createVal ="User do not created";
			logger.error("Unable to create. A User with name {} already exist", user.getName());
			return createVal;
		}
		userService.saveUser(user);
		createVal ="User are created";
		return createVal;
	}

	// ------------------- Update a User ------------------------------------------------

	@RequestMapping(value = "/user/{id}", method = RequestMethod.PUT)
	public String updateUser(@PathVariable("id") long id, @RequestBody User user) {
		logger.info("Updating User with id {}", id);

		User currentUser = userService.findById(id);
		String updatedVal ="";
		if (currentUser == null) {
			logger.error("Unable to update. User with id {} not found.", id);
			updatedVal =id+" id Of User do not updated";
			return updatedVal;
		}

		currentUser.setName(user.getName());
		currentUser.setAge(user.getAge());
		currentUser.setSalary(user.getSalary());

		userService.updateUser(currentUser);
		updatedVal =id+" id Of User is updated";
		return updatedVal;
	}

	// ------------------- Delete a User-----------------------------------------

	@RequestMapping(value = "/user/{id}", method = RequestMethod.DELETE)
	public String deleteUser(@PathVariable("id") long id) {
		logger.info("Fetching & Deleting User with id {}", id);

		User user = userService.findById(id);
		String deleteVal ="";
		if (user == null) {
			deleteVal=id+" id of user are not delete";
			logger.error("Unable to delete. User with id {} not found.", id);
			return deleteVal ;
		}
		userService.deleteUserById(id);
		deleteVal =id+" id of user are delete";
		
		return deleteVal;
	}

	// ------------------- Delete All Users-----------------------------

	@RequestMapping(value = "/user/", method = RequestMethod.DELETE)
	public String deleteAllUsers() {
		logger.info("Deleting All Users");

		userService.deleteAllUsers();
		String deleteAllVal ="All User are delete";
		return deleteAllVal;
		
	}

}