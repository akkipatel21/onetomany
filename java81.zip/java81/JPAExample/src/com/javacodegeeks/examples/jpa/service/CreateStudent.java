package com.javacodegeeks.examples.jpa.service;

import java.util.Scanner;

import javax.persistence.*;

import com.javacodegeeks.examples.jpa.entity.Student;

import oracle.jdbc.*;

public class CreateStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory( "RivuChk_JPA" );
	   	EntityManager entitymanager = emfactory.createEntityManager( );
	   	entitymanager.getTransaction( ).begin( );
	   	
	   	Student student=new Student();
	   	
	   	System.out.println("Enter ID");
	   	student.setSid(sc.nextInt());
	   	
	   	System.out.println("Enter First Name");
	   	student.setFname(sc.next());
	   	
	   	System.out.println("Enter Last Name");
	   	student.setLname(sc.next());
	   	
	   	System.out.println("Enter Department");
	   	student.setDept(sc.next());
	   	
	   	System.out.println("Enter Year");
	   	student.setYear(sc.nextInt());
	   	
	   	System.out.println("Enter Email ID");
	   	student.setEmail(sc.next());
	   	
	   	entitymanager.persist(student);
	   	entitymanager.getTransaction().commit();
	   	
	   	entitymanager.close();
	   	emfactory.close();
	   	
	}

}
