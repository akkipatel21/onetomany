package com.javacodegeeks.examples.jpa.service;


import java.util.Scanner;
import org.eclipse.persistence.sessions.Session;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.ParameterMode;
import javax.persistence.Persistence;
import javax.persistence.StoredProcedureQuery;

import org.eclipse.persistence.jpa.JpaEntityManager;


import com.javacodegeeks.examples.jpa.entity.Student;

public class JpaINParam {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory( "RivuChk_JPA" );
		EntityManager entitymanager =  emfactory.createEntityManager();
		
		
		
		System.out.println("Enter ID to View");
		int id=sc.nextInt();
		
		StoredProcedureQuery storedProcedure = entitymanager.createStoredProcedureQuery("studentById");
		// set parameters
		storedProcedure.registerStoredProcedureParameter("id", Integer.class, ParameterMode.IN);
		storedProcedure.registerStoredProcedureParameter("sname", String.class, ParameterMode.OUT);
		storedProcedure.registerStoredProcedureParameter("dept", String.class, ParameterMode.OUT);
		storedProcedure.setParameter("id", id);
		// execute SP
		storedProcedure.execute();
		
		
			String name=storedProcedure.getOutputParameterValue("sname").toString();
			String dept=storedProcedure.getOutputParameterValue("dept").toString();
			
			System.out.println("Name : "+name);
			System.out.println("Department : "+dept);
		
		
		
		
		
	}

	}


