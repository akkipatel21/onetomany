/**
 * 
 */
package com.javacodegeeks.examples.jpa.service;

import java.util.Iterator;
import java.util.List;

import javax.persistence.*;
import javax.management.Query;

import org.eclipse.persistence.internal.sessions.ArrayRecord;
import org.eclipse.persistence.jpa.JpaEntityManager;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.eclipse.persistence.*;

import com.javacodegeeks.examples.jpa.entity.Student;



/**
 * @author Rivu
 *
 */
public class JPAcreateNamedQuery {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory( "RivuChk_JPA" );
		EntityManager entitymanager =  emfactory.createEntityManager();
		
		
		javax.persistence.Query query =  entitymanager.createNamedQuery("studentAll");
		List<Student> students =  query.getResultList();
		
		System.out.println("The Students are:");
		//Looping Through the Resultant list
		for(Student student:students)
		{
			System.out.println(student.toString());
		}
		
		
	}

}
