package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.repository.UserRepository;
import com.example.model.User;

@Service("userService")
@CacheConfig(cacheNames = {"directory", "users"})
public class UserServiceImpl implements UserService{
	
	@Autowired
	UserRepository userRepo;
	
	//@Modifying(clearAutomatically = true)
	@Cacheable(value="users")
	public List<User> findAllUsers() {
		System.out.println("fetchind method findAllUsers >>>>>>>>>>>>>>>>>>");
        return (List<User>) userRepo.findAll();
    }
     
	@Cacheable(value="users", key="#id")
	//@Cacheable(value="users")
    public User findById(long id) {
		System.out.println("fetchind method findById >>>>>>>>>>>>>>>>>>");
        return userRepo.findOne(id);
    }
    
	@Cacheable(value="users", key="#name")
    public List<User> findUserByName(String userName) {
		System.out.println("fetchind method findUserByName >>>>>>>>>>>>>>>>>");
        return userRepo.findUser(userName);
    }
     
    public void saveUser(User user) {
    	System.out.println("fetchind method >>>>>>>>>>>>>>>>");
    	userRepo.save(user);
    }
    
    @CachePut(value="users", key="#id")
    public User updateUser(User user,long id) {
    	System.out.println("fetchind method updateUser >>>>>>>>>>>>>>>>>");
    	User currentUser = userRepo.findOne(id);
    	currentUser.setAge(user.getAge());
    	currentUser.setName(user.getName());
    	currentUser.setSalary(user.getSalary());
    	userRepo.save(currentUser);
    	
    	return currentUser;
    }
    
    @CacheEvict(value = "users", key = "#id")
    public void deleteUserById(long id) {
    	System.out.println("fetchind method deleteUserById >>>>>>>>>>> ");
    	User currentUser = userRepo.findOne(id);
    	userRepo.delete(currentUser);
    }
    	
}
