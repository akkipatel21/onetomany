
public class FunctionalInterfaceExample implements SaySomthing {
	public void say(String msg) {
		System.out.println(msg); 
	}
	public static void main(String[] args) {
		FunctionalInterfaceExample f =new FunctionalInterfaceExample();
		f.say("hi i'm here");
	}
}
