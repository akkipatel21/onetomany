@FunctionalInterface
public interface SaySomthing {
	void say(String msg);
	
	int hashCode();  
	String toString();
	boolean equals(Object obj); 
}
