import java.util.StringJoiner;

public class JavaStringJoiner {

	public static void main(String[] args) {
		StringJoiner joinNames = new StringJoiner(","); // passing comma(,) as delimiter   
        
        // Adding values to StringJoiner  
        joinNames.add("Rutvik");  
        joinNames.add("pratik");  
        joinNames.add("juhi"); 
                  
        System.out.println(joinNames); 
        
        
        StringJoiner joinNam = new StringJoiner(",", "[", "]");   // passing comma(,) and square-brackets as delimiter   
        
        // Adding values to StringJoiner  
        joinNam.add("Rutvik");  
        joinNam.add("pratik");  
  
        // Creating StringJoiner with :(colon) delimiter  
        StringJoiner joinNames2 = new StringJoiner(":", "[", "]");  // passing colon(:) and square-brackets as delimiter   
          
        // Adding values to StringJoiner  
        joinNames2.add("vikash");  
        joinNames2.add("juhi");  
  
        // Merging two StringJoiner  
        StringJoiner merge = joinNam.merge(joinNames2);
        System.out.println(merge);  

	}

}
