
public class LambdaExpressionExample{

	public static void main(String[] args) {
		Simple s = (name)->{
			return "hello"+name;
		};
		System.out.println(s.sim("pratik"));
	}

}
