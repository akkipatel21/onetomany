@FunctionalInterface
public interface Simple {
public String sim(String name);
//public void mayname();
}
