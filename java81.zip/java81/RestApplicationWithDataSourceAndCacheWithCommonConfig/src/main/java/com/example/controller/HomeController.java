package com.example.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.User;
import com.example.service.UserService;
import com.fasterxml.jackson.annotation.JsonIdentityReference;

@RefreshScope
@RestController
@RequestMapping("/api")
public class HomeController {
	
	@Autowired
	UserService userService;
	
	@RequestMapping(value = "/user", method = RequestMethod.GET)
    public List<User> listAllUsers() {
		System.out.println("Fetching Users list");
		List<User> users = userService.findAllUsers();
        if (users.isEmpty()) {
        	return new ArrayList<User>();
        }
        return users;
    }
 
	/*@RequestMapping(value = "/searchUser", method = RequestMethod.GET)
    public List<User> listAllUsers() {
		System.out.println("Fetching Users list");
		List<User> users = userService.findAllUsers();
        if (users.isEmpty()) {
        	return new ArrayList<User>();
        }
        return users;
    }*/
	
    @RequestMapping(value = "/user/{id}", method = RequestMethod.GET)
    public User getUser(@PathVariable("id") long id) {
        System.out.println("Fetching User with id {}" + id);
        User user = userService.findById(id);
        if (user == null) {
            System.out.println("User with id {} not found." + id);
            return new User();
        }
        return user;
    }
 
    @RequestMapping(value = "/user", method = RequestMethod.POST)
    public String createUser(@RequestBody User user) {
        System.out.println("Creating User : {}" + user);
        String createVal ="";
        userService.saveUser(user);
        createVal ="user is created";
        HttpHeaders headers = new HttpHeaders();
        return createVal;
    }
 
    @RequestMapping(value = "/user/{id}", method = RequestMethod.PUT)
    public String updateUser(@PathVariable("id") long id, @RequestBody User user) {
        System.out.println("Updating User with id {}" +  id);
        
        User currentUser = userService.findById(id);
        String updatedVal ="";
        if (currentUser == null) {
            System.out.println("Unable to update. User with id {} not found." + id);
            updatedVal =id+" id Of User do not updated";
            return  updatedVal;
        }
        
        //currentUser.setName(user.getName());
       // currentUser.setAge(user.getAge());
       // currentUser.setSalary(user.getSalary());
 
        userService.updateUser(user,id);
        updatedVal =id+" id Of User is updated";
        return updatedVal;
    }
    
 
    @RequestMapping(value = "/user/{id}", method = RequestMethod.DELETE)
    public String deleteUser(@PathVariable("id") long id) {
        System.out.println("Fetching & Deleting User with id {}" + id);
        
        User user = userService.findById(id);
        String deleteVal ="";
        if (user == null) {
            System.out.println("Unable to delete. User with id {} not found." + id);
            deleteVal=id+" id of user are not delete";
            return deleteVal;
        }
        userService.deleteUserById(id);
        deleteVal =id+" id of user are delete";
        return deleteVal;
    }
    
    @RequestMapping(value = "/userbyname/{name}", method = RequestMethod.GET)
    public String getUserByName(@PathVariable("name") String name) {
    	System.out.println("Fetching User with name {}" + name);
        
        List<User> users = userService.findUserByName(name);
        String getUserName ="";
        if (users == null) {
            System.out.println("Unable to fatch. User with name {} not found." + name);
            getUserName=name+" Unable to found";
            return getUserName;
        }
        getUserName=name+" user to fatch";
        return getUserName;
    }
    
    @RequestMapping(value = "/searching/{name}", method = RequestMethod.GET)
    public List<User> searchingUserByName(@PathVariable("name") String name) {
    	System.out.println("Fetching User with name {}" + name);
        
        List<User> users = userService.findAllUsers();
        Predicate<User> p1 = e -> e.getName().equalsIgnoreCase(name)  && e.getDflag() == 1;
        boolean b1 = users.stream().anyMatch(p1);
	    System.out.println(b1);
		//List<String>  val1 =emplist.stream().filter(e->e.getFirstname() == search).map(e->e.getFirstname()).collect(Collectors.toList());
		List<User>  val1 =(List<User>) users.stream().parallel().filter(e->e.getName().equalsIgnoreCase(name) && e.getDflag() ==1).sequential().collect(Collectors.toList());
      // Long  val2 =plist.stream().filter(p->p.name == "pratik").map(p->p.name).collect(Collectors.counting());
       System.out.println("val1 ::"+val1);
        String getUserName ="";
        if (users == null) {
            System.out.println("Unable to fatch. User with name {} not found." + name);
            getUserName=name+" Unable to found";
            return new ArrayList<User>();
        }
        getUserName=name+" user to fatch";
        return val1;
    }
    
    @RequestMapping(value = "/testparam/{name}/{salary}", method = RequestMethod.GET)
    public ResponseEntity<String> getSalaryByName(@PathVariable("name") String name,@PathVariable("salary") String salary) {
    	System.out.println("Fetching User with name {}" + name);
    	System.out.println("Fetching User with salary {}" + salary);
        
        return new ResponseEntity<String>("Success", HttpStatus.OK);
    }
    
}
