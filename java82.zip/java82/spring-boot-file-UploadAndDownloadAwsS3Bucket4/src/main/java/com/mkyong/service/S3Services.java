package com.mkyong.service;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;

import com.amazonaws.services.s3.transfer.Download;

public interface S3Services {
	public ResponseEntity<InputStreamResource> downloadFile(String keyName, String downloadFilePath);
}
