package com.mkyong.serviceimpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.servlet.ServletContext;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.event.ProgressEvent;
import com.amazonaws.event.ProgressListener;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.services.s3.transfer.Download;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.Upload;
import com.mkyong.exception.MediaTypeUtils;
import com.mkyong.service.S3Services;

@Service
public class S3ServicesImpl implements S3Services{
	
	protected Logger logger = LoggerFactory.getLogger(S3ServicesImpl.class);
	
	@Autowired
	protected TransferManager transferManager;

	@Value("${jsa.s3.bucket}")
	protected String bucketName;
	
	
	@Value("${jsa.s3.region}")
	private String region;

	@Autowired
	private ServletContext servletContext;

	/**
	 * UPLOAD FILE to Amazon S3
	 */
	
	/**
	 * DOWNLOAD FILE from Amazon S3
	 */
	@Override
	public ResponseEntity<InputStreamResource> downloadFile(String keyName, String downloadFilePath) {
		
		/*
		final GetObjectRequest request = new GetObjectRequest(bucketName, keyName);
		System.out.println("keyName ::: "+keyName);
		System.out.println("downloadFilePath ::: "+downloadFilePath);
		String str ="";
		request.setGeneralProgressListener(new ProgressListener() {
			@Override
			public void progressChanged(ProgressEvent progressEvent) {
				String transferredBytes = "Downloaded bytes: " + progressEvent.getBytesTransferred();
				System.out.println("transferredBytes :: "+transferredBytes);
				//logger.info(transferredBytes);
			}
		});
		//AmazonS3 s3 = AmazonS3ClientBuilder.defaultClient();
		//s3client().copyObject(bucketName, keyName, downloadFilePath, keyName);
		//Download download =null;
		Download download = transferManager.download(request, new File(downloadFilePath));
		return download;
		*/
		//double tsanferPercentage=0;
		//final GetObjectRequest request = new GetObjectRequest(bucketName, keyName);
	    //Download download = transferManager.download(request, new File(downloadFilePath));
	    
	    /*while (!download.isDone()) {
	        logger.info("Downloaded >> " + download.getProgress().getPercentTransferred());
	        tsanferPercentage = download.getProgress().getBytesTransferred();
	        //return download;
	    }*/
	    AmazonS3 s3Client =null;
	    S3Object s3object = s3Client.getObject(bucketName, keyName);
	  //  S3Object s3object = s3Client.getObject(bucketName, "picture/pic.png");
	    S3ObjectInputStream inputStream = s3object.getObjectContent();
	    try {
			FileUtils.copyInputStreamToFile(inputStream, new File(downloadFilePath));
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	    MediaType mediaType = MediaTypeUtils.getMediaTypeForFileName(this.servletContext, downloadFilePath);
        System.out.println("fileName: " + downloadFilePath);
        System.out.println("mediaType: " + mediaType);
	    
	    File file = new File(downloadFilePath);
        InputStreamResource resource =null;
		try {
			resource = new InputStreamResource(new FileInputStream(file));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 
        return ResponseEntity.ok()
                // Content-Disposition
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + file.getName())
                // Content-Type
                .contentType(mediaType)
                // Contet-Length
                .contentLength(file.length()) //
                .body(resource);
	    //ProgressListener listener = progressEvent -> logger.info("Bytes transfer >> " + progressEvent.getBytesTransferred());

	    //GetObjectRequest s3Request = new GetObjectRequest(bucketName, keyName);
	  
	    //Download download1 = transferManager.download(s3Request, new File(downloadFilePath));

	   // download.addProgressListener(listener);
	    /*try 
	    {
			download.waitForCompletion();
			
		} catch (AmazonServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AmazonClientException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//return download1;
		return download1;*/
		
	}
	
	/*@Bean
	public AmazonS3 s3client() {
		//
		//BasicAWSCredentials awsCreds = new BasicAWSCredentials(awsId, awsKey);
		//AmazonSNSClient ansClient = new AmazonSNSClient(new DefaultAWSCredentialsProviderChain());
		AmazonS3 s3Client = AmazonS3ClientBuilder.standard()
								.withRegion(Regions.fromName(region))
		                        //.withCredentials(new AWSStaticCredentialsProvider(awsCreds))
		                        .build();
		
		return s3Client;
	}*/

	/*@Override
	public void uploadFile1(String keyName,String uploadFilePath) {
		final PutObjectRequest request = new PutObjectRequest(bucketName, keyName, new File(uploadFilePath));
		//String bucketName = "baeldung-bucket";
		 
		if(s3client.doesBucketExist(bucketName)) {
		    System.out.println("Bucket name is not available."
		      + " Try again with a different Bucket name.");
		    return;
		}
		 
		//s3client.createBucket(bucketName);
		request.setGeneralProgressListener(new ProgressListener() {
			@Override
			public void progressChanged(ProgressEvent progressEvent) {
				String transferredBytes = "Uploaded bytes: " + progressEvent.getBytesTransferred();
				logger.info(transferredBytes);
			}
		});

		Upload upload = transferManager.upload(request);
		
		// Or you can block and wait for the upload to finish
		try {
			
			upload.waitForCompletion();
			
		} catch (AmazonServiceException e) {
			logger.info(e.getMessage());
		} catch (AmazonClientException e) {
			logger.info(e.getMessage());
		} catch (InterruptedException e) {
			logger.info(e.getMessage());
		}
	}*/
}
