package com.mkyong.controller;


import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.event.ProgressListener;
import com.amazonaws.services.s3.transfer.Download;
import com.mkyong.exception.FileDownloadThread;
import com.mkyong.model.UploadModel;
import com.mkyong.service.S3Services;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;


//new 
import javax.servlet.Servlet;
import javax.servlet.http.HttpServlet;
import java.io.*;
import java.util.*;
import javax.servlet.http.*;
import org.apache.commons.fileupload.*;
import javax.servlet.ServletException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

@RestController
public class RestUploadController {

    private final Logger logger = LoggerFactory.getLogger(RestUploadController.class);

    //Save the uploaded file to this folder
    private static String UPLOADED_FOLDER = "C:/Users/pratikj/Desktop/spring-boot-master/";
    
    @Autowired
	S3Services s3Services;
	
	@Value("${jsa.s3.uploadfile}")
	private String uploadFilePath;
	
	@Value("${jsa.s3.downloadfile}")
	private String downloadFilePath;
	
	@Value("${jsa.s3.key}")
	private String key;
    
    //Single file upload
    @PostMapping("/api/upload")
    // If not @RestController, uncomment this
    //@ResponseBody
    public ResponseEntity<?> uploadFile(
            @RequestParam("file") MultipartFile uploadfile) {

        logger.debug("Single file upload!");

        if (uploadfile.isEmpty()) {
            return new ResponseEntity("please select a file!", HttpStatus.OK);
        }

        try {

            saveUploadedFiles(Arrays.asList(uploadfile));

        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        return new ResponseEntity("Successfully uploaded - " +
                uploadfile.getOriginalFilename(), new HttpHeaders(), HttpStatus.OK);

    }

    // Multiple file upload
    @PostMapping("/api/upload/multi")
    public ResponseEntity<?> uploadFileMulti(
            @RequestParam("extraField") String extraField,
            @RequestParam("files") MultipartFile uploadfiles) throws IOException {

        logger.debug("Multiple file upload!");
        System.out.println("extraField "+extraField);
        System.out.println("uploadfiles "+uploadfiles);
        
        String myString = uploadfiles.getName();
        /*InputStream in = uploadfiles.getInputStream();
    	char read = 0;
    	byte[] bytes = new byte[1024];
    	while((read = (char) in.read(bytes)) != -1) {
    		myString += read;
    	}*/
    	
       File f = convert(uploadfiles);
        
        /*String uploadedFileName = Arrays.stream(uploadfiles).map(x -> x.getOriginalFilename())
                .filter(x -> !StringUtils.isEmpty(x)).collect(Collectors.joining(" , "));*/
       
        if (StringUtils.isEmpty(uploadfiles.getName())) {
            return new ResponseEntity("please select a file!", HttpStatus.OK);
        }
        JSONParser parser = new JSONParser();
        try {
        	
        	
        	if (!uploadfiles.isEmpty()) {

        		 Object obj = parser.parse(new FileReader(f));
        		// Object obj = parser.parse(new FileReader(uploadfiles.getOriginalFilename()));
                 System.out.println("obj :: "+obj);
                 JSONObject jsonObject = (JSONObject) obj;
                 
                 String name = (String) jsonObject.get("Name");
                 String author = (String) jsonObject.get("Author");
                 JSONArray companyList = (JSONArray) jsonObject.get("Company List");
      
                 System.out.println("Name: " + name);
                 System.out.println("Author: " + author);
                 System.out.println("\nCompany List:");
                 Iterator<String> iterator = companyList.iterator();
                 while (iterator.hasNext()) {
                     System.out.println(iterator.next());
                 } 

            } 
        	
           

        } catch (Exception e) {
            e.printStackTrace();
        }

        return new ResponseEntity("Successfully uploaded - "
                + myString, HttpStatus.OK);

    }
    @PostMapping("/api/s3/upload/multi")
    public ResponseEntity<?> uploadS3FileMulti(
            @RequestParam("extraField") String extraField,
            @RequestParam("files") MultipartFile uploadfiles) throws IOException {

        logger.debug("Multiple file upload!");
        System.out.println("extraField "+extraField);
        System.out.println("uploadfiles "+uploadfiles);
        
        String myString = uploadfiles.getName();
        
    	
       File f = convert(uploadfiles);
        
        /*String uploadedFileName = Arrays.stream(uploadfiles).map(x -> x.getOriginalFilename())
                .filter(x -> !StringUtils.isEmpty(x)).collect(Collectors.joining(" , "));*/
       
        if (StringUtils.isEmpty(uploadfiles.getName())) {
            return new ResponseEntity("please select a file!", HttpStatus.OK);
        }
        JSONParser parser = new JSONParser();
        try {
        	
        	
        	if (!uploadfiles.isEmpty()) {

        		 Object obj = parser.parse(new FileReader(f));
        		// Object obj = parser.parse(new FileReader(uploadfiles.getOriginalFilename()));
                 System.out.println("obj :: "+obj);
                 JSONObject jsonObject = (JSONObject) obj;
                 
                 String name = (String) jsonObject.get("Name");
                 String author = (String) jsonObject.get("Author");
                 JSONArray companyList = (JSONArray) jsonObject.get("Company List");
      
                 System.out.println("Name: " + name);
                 System.out.println("Author: " + author);
                 System.out.println("\nCompany List:");
                 Iterator<String> iterator = companyList.iterator();
                 while (iterator.hasNext()) {
                     System.out.println(iterator.next());
                 } 

            } 
        	
           

        } catch (Exception e) {
            e.printStackTrace();
        }

        return new ResponseEntity("Successfully uploaded - "
                + myString, HttpStatus.OK);

    }
    
    @PostMapping("/api/s3/upload/download")
    public ResponseEntity<InputStreamResource> downloadS3FileMulti (
           // @RequestParam("extraField") String extraField,
           // @RequestParam("files") MultipartFile uploadfiles
            ) {
    	Date d = new Date();
    	
        logger.debug("Multiple file upload!");
        System.out.println("---------------- START DOWNLOAD FILE ----------------");
        ResponseEntity<InputStreamResource> download =s3Services.downloadFile(key, downloadFilePath);
       // System.out.println("sr.getProgress().getTotalBytesToTransfer() :: "+download.getProgress().getTotalBytesToTransfer()+" time ::"+d);
       
        //String bytes = download.getProgress().getBytesTransferred()+"";
        //System.out.println(""+bytes);
		//System.out.println("DONE!");
		//System.out.println("sr.getProgress().getTotalBytesToTransfer() 2 :: "+download.getProgress().getTotalBytesToTransfer()+" time ::"+d);
		//System.out.println("sr.getProgress().getTotalBytesToTransfer() 2 :: "+download.getProgress().+" time ::"+d);
		//System.out.println("sr.getProgress().getPercentTransferred() 3 :: "+download.getProgress().getPercentTransferred()+" time ::"+d);
		//System.out.println("bytes.getBytes() ::: "+bytes.getBytes().toString());

        return download;

    }
    
    @PostMapping("/downloadFileProgress")
    public Download downloadFileProgress (
           @RequestParam("download") Download download
           // @RequestParam("files") MultipartFile uploadfiles
            ) {
    	Date d = new Date();
    	
        logger.debug("Multiple file upload!");
        System.out.println("---------------- START DOWNLOAD FILE ----------------");
        double tsanferPercentage=0;
        while (!download.isDone()) {
	        logger.info("Downloaded >> " + download.getProgress().getPercentTransferred());
	        tsanferPercentage = download.getProgress().getBytesTransferred();
	        //return download;
	    }
        ProgressListener listener = progressEvent -> logger.info("Bytes transfer >> " + progressEvent.getBytesTransferred());
        download.addProgressListener(listener);
	    try 
	    {
			download.waitForCompletion();
			
		} catch (AmazonServiceException e) {
			e.printStackTrace();
		} catch (AmazonClientException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("DONE!");
		System.out.println("sr.getProgress().getTotalBytesToTransfer() 2 :: "+download.getProgress().getTotalBytesToTransfer()+" time ::"+d);
		//System.out.println("sr.getProgress().getTotalBytesToTransfer() 2 :: "+download.getProgress().+" time ::"+d);
		System.out.println("sr.getProgress().getPercentTransferred() 3 :: "+download.getProgress().getPercentTransferred()+" time ::"+d);
		//System.out.println("bytes.getBytes() ::: "+bytes.getBytes().toString());

        return download;

    }
    
    @PostMapping("/api/s3/upload/download2")
    public String downloadS3FileMulti2(
           // @RequestParam("extraField") String extraField,
           // @RequestParam("files") MultipartFile uploadfiles
            ) throws IOException {

    	String sr ="";
    	//public class FileUploadServlet extends HttpServlet implements Servlet {
    	
    	    /*private static final long serialVersionUID = 2740693677625051632L;
    	
    	    public FileUploadServlet() {
    	        super();
    	    }

    		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	        PrintWriter out = response.getWriter();
    		    HttpSession session = request.getSession();
    	        FileUploadListener listener = null;
    			StringBuffer buffy = new StringBuffer();
    		    long bytesRead = 0, contentLength = 0;

    	        if (session == null) {
    	            return;
    		    } else if (session != null) {
    	            listener = (FileUploadListener) session.getAttribute("LISTENER");

    		        if (listener == null) {
    			        return;
    	            } else {
    		            bytesRead = listener.getBytesRead();
    	                contentLength = listener.getContentLength();
    		        }
    	        }

    		    response.setContentType("text/xml");
    	
    		    buffy.append("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n");
    			buffy.append("<response>\n");
    	        buffy.append("\t<bytes_read>" + bytesRead + "</bytes_read>\n");
    	        buffy.append("\t<content_length>" + contentLength + "</content_length>\n");

    	        if (bytesRead == contentLength) {
    	            buffy.append("\t<finished />\n");
    		        session.setAttribute("LISTENER", null);
    	        } else {
    		        long percentComplete = ((100 * bytesRead) / contentLength);
    	            buffy.append("\t<percent_complete>" + percentComplete + "</percent_complete>\n");
    		    }
    	        buffy.append("</response>\n");
    		    out.println(buffy.toString());
    	        out.flush();
    		    out.close();
    	    }

    		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	        FileItemFactory factory = new DiskFileItemFactory();
    		    ServletFileUpload upload = new ServletFileUpload(factory);
    	        FileUploadListener listener = new FileUploadListener();
    		    HttpSession session = request.getSession();
    			session.setAttribute("LISTENER", listener);
    	        upload.setProgressListener(listener);
    		    List uploadedItems = null;
    			FileItem fileItem = null;
    	        String filePath = "c:\\temp";

    		    try {
    			    uploadedItems = upload.parseRequest(request);
    	            Iterator i = uploadedItems.iterator();
    	
    		        while (i.hasNext()) {
    			        fileItem = (FileItem) i.next();
    				    if (fileItem.isFormField() == false) {
    					    if (fileItem.getSize() > 0) {
    						    File uploadedFile = null;
    							String myFullFileName = fileItem.getName(), myFileName = "", slashType = (myFullFileName.lastIndexOf("\\") > 0) ? "\\" : "/";
    	                        int startIndex = myFullFileName.lastIndexOf(slashType);
    		                    myFileName = myFullFileName.substring(startIndex + 1, myFullFileName.length());
    			                uploadedFile = new File(filePath, myFileName);
    				            fileItem.write(uploadedFile);
    					    }
    	                }
    		        }
    			} catch (FileUploadException e) {
    	            e.printStackTrace();
    		    } catch (Exception e) {
    			    e.printStackTrace();
    	        }
    		}
    	}*/

        return sr;

    }
    public static File convert(MultipartFile file) throws IOException {
        File convFile = new File(file.getOriginalFilename());
        convFile.createNewFile();
        FileOutputStream fos = new FileOutputStream(convFile);
        fos.write(file.getBytes());
        fos.close();
        return convFile;
    }

    // maps html form to a Model
    @PostMapping("/api/upload/multi/model")
    public ResponseEntity<?> multiUploadFileModel(@ModelAttribute UploadModel model) {

        logger.debug("Multiple file upload! With UploadModel");

        try {

            saveUploadedFiles(Arrays.asList(model.getFiles()));

        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        return new ResponseEntity("Successfully uploaded!", HttpStatus.OK);

    }

    //save file
    private void saveUploadedFiles(List<MultipartFile> files) throws IOException {

        for (MultipartFile file : files) {

            if (file.isEmpty()) {
                continue; //next pls
            }

            byte[] bytes = file.getBytes();
            Path path = Paths.get(UPLOADED_FOLDER + file.getOriginalFilename());
            Files.write(path, bytes);

        }

    }

	
}
