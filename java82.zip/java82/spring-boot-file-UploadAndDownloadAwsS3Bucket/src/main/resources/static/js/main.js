var progressBarValue=0;
$(document).ready(function () {
	//$( "#progressbar" ).progressbar({             value:0         });
	//document.getElementById("progressbarWrapper").style.display = "none";
	var elem = document.getElementById("myBar");
 	 
 		elem.max = 0;
 		elem.value = 0;
 	    
    $("#btnSubmit").click(function (event) {

        //stop submit the form, we will post it manually.
        event.preventDefault();

        //fire_ajax_submit();
        ///api/s3/upload/multi
        fire_ajax_submit1();
    });

});
function updateProgressBar(progressBarValue)
{
	$("#progressbar").progressbar("option","value",progressBarValue);
}
var req;

function ajaxFunction(){
	var url = "/api/s3/upload/download";
    
    if (window.XMLHttpRequest){ 
		req = new XMLHttpRequest();
        try{
			req.onreadystatechange = funcReadyStateChange;
            req.open("POST", url, true);
        } catch (e) {
			alert(e);
        }
        req.send(null);
    }

    else if (window.ActiveXObject) { 
		req = new ActiveXObject("Microsoft.XMLHTTP");
        if (req) {
			req.onreadystatechange = funcReadyStateChange;
            req.open("GET", url, true);
            req.send();
        }
    }
}
     


function fire_ajax_submit() {

    // Get form
    var form = $('#fileUploadForm')[0];

    var data = new FormData(form);

    data.append("CustomField", "This is some extra data, testing");

    $("#btnSubmit").prop("disabled", true);

    $.ajax({
        type: "POST",
        enctype: 'multipart/form-data',
        url: "/api/upload/multi",
        data: data,
        //http://api.jquery.com/jQuery.ajax/
        //https://developer.mozilla.org/en-US/docs/Web/API/FormData/Using_FormData_Objects
        processData: false, //prevent jQuery from automatically transforming the data into a query string
        contentType: false,
        cache: false,
        timeout: 600000,
        success: function (data) {

            $("#result").text(data);
            console.log("SUCCESS : ", data);
            $("#btnSubmit").prop("disabled", false);

        },
        error: function (e) {

            $("#result").text(e.responseText);
            console.log("ERROR : ", e);
            $("#btnSubmit").prop("disabled", false);

        }
    });

}
function fire_ajax_submit1() {

    // Get form
    var form = $('#fileUploadForm')[0];

    var data = new FormData(form);

    data.append("CustomField", "This is some extra data, testing");

    $("#btnSubmit").prop("disabled", true);

    $.ajax({
        type: "POST",
        enctype: 'multipart/form-data',
        url: "/api/s3/upload/multi",
        data: data,
        processData: false,
        contentType: false,
        cache: false,
        timeout: 600000,
        success: function (data) {

            $("#result").text(data);
            console.log("SUCCESS : ", data);
            $("#btnSubmit").prop("disabled", false);
            dowload_ajax_submit2();
           // downloadFile();

        },
        error: function (e) {

            $("#result").text(e.responseText);
            console.log("ERROR : ", e);
            $("#btnSubmit").prop("disabled", false);

        }
    });
} 
    
    /*function dowload_ajax_submit1() {

    	$.ajax({
    	    type: 'POST',
    	    url: "/api/s3/upload/download",
    	    //data: {},
    	    beforeSend: function(XMLHttpRequest){
    	       
    	        //Download progress
    	        XMLHttpRequest.addEventListener("progress", function(evt){
    	            if (evt.lengthComputable) {  
    	                var percentComplete = evt.loaded / evt.total;
    	                //Do something with download progress
    	                console.log("percentComplete :: "+percentComplete)
    	            }
    	        }, false); 
    	    },
    	    success: function(data){
    	        //Do something success-ish
    	    	console.log("data"+data);
    	    }
    	});
    	

}*/
/*function progress() {
    var val = progressbar.progressbar( "value" ) || 0;

    progressbar.progressbar( "value", val + 2 );

    if ( val < 99 ) {
      setTimeout( progress, 80 );
    }
  }*/

  //setTimeout( progress, 2000 );
//} );
var size =82694252;
var size1 = (5*1024);
var final ;

    function dowload_ajax_submit1() {
    	
    	var xhr = new window.XMLHttpRequest();
    	xhr.open("POST","http://192.168.150.170:8080/Chart/file.zip");//api/s3/upload/download
    	//xhr.overrideMimeType("text/plain; charset=x-user-defined");
    	xhr.responseType = "arraybuffer";
    	xhr.addEventListener("progress", updateProgress);
    	xhr.addEventListener("load", transferComplete);
    	xhr.addEventListener("error", transferFailed);

    	//xhr.open(null);
    	xhr.send();
    	
    	
    	/*$.ajax({
    	    type: 'POST',
    	    url: "api/s3/upload/download",
    	    //data: {},
    	    success: function (data) {
    	    	//dowload_ajax_progress(data);
    	    	if(data == 'success'){
    	    		final =data;
    	    	}
    	    	console.log("totalbytes ::"+data);
    	    	if(data == size){
    	    		
    	    		//dowload_ajax_submit1();
    	    		size = (size - size1);
    	    	}
    	    },
    	    progress: function(data){
    	    	console.log("xhr call  "+data);
    	        var xhr = new window.XMLHttpRequest();
    	        var progressBar = document.getElementById("progress");
    	       
    	        alert('file download');
    	        xhr.addEventListener("progress", function(evt){
    	        	 console.log('file loaded: '+size1);
    	        	 console.log('file total: '+size);
    	        	
    	             if (evt.lengthComputable) {
    	               var percentComplete = (size / size1)*100;
    	               //Do something with download progress
    	               console.log('evt.loaded ::: '+evt.loaded);
    	               console.log('evt.total ::: '+evt.total);
    	               //$('#download').show();
    	               	progressBar.max = size;
   	                	progressBar.value = size1;
    	               console.log(percentComplete);
    	             }
    	             //return xhr;
    	        }, false);
    	        xhr.onloadstart = function(e) {
    	            progressBar.value = 0;
    	        };
    	        xhr.onloadend = function(e) {
    	            progressBar.value = size1;
    	        };
    	        	
    	        return xhr;
    	     },
    	    
    	 });*/
    	

}
    function updateProgress(e){
    	console.log('updateProgress');
    }
    function transferComplete(e){
    	console.log('tranfer complete');
    }
	 function transferFailed(e){
		 console.log('tranfer failed');
	 }

    function dowload_ajax_progress(data) {

    	$.ajax({
    	    type: 'POST',
    	    url: "downloadFileProgress",
    	    data: data.getProgress().getBytesTransferred(),
    	    success: function (data) {
    	    	if(!data.isDone()){
    	    		dowload_ajax_progress(data);
    	    	}
    	    },
    	    xhr: function(data){
    	    	//console.log("xhr call  "+this+" "+xhr);
    	        var xhr = new window.XMLHttpRequest();
    	        var progressBar = document.getElementById("progress");
    	       
    	       // alert('file download');
    	        xhr.addEventListener("progress", function(evt){
    	        	 console.log('file loaded: '+evt.loaded);
    	        	 console.log('file total: '+evt.total);
    	             if (evt.lengthComputable) {
    	               var percentComplete = evt.loaded / evt.total;
    	               //Do something with download progress
    	               console.log('evt.loaded ::: '+evt.loaded);
    	               console.log('evt.total ::: '+evt.total);
    	               //$('#download').show();
    	               	progressBar.max = evt.total;
   	                	progressBar.value = evt.loaded;
    	               console.log(percentComplete);
    	             }
    	             //return xhr;
    	        }, false);
    	        xhr.onloadstart = function(e) {
    	            progressBar.value = 0;
    	        };
    	        xhr.onloadend = function(e) {
    	            progressBar.value = e.loaded;
    	        };
    	        	
    	        return xhr;
    	     },
    	    
    	 });
    	

}
    
    var progress;
    function dowload_ajax_submit3() {
    	progress = setInterval(function () {
    	$.ajax({
    	    type: 'POST',
    	    url: "/api/s3/upload/download",
    	    //data: {},
    	    xhr: function(){
    	    	//console.log("xhr call  "+this+" "+xhr);
    	        var xhr = new window.XMLHttpRequest();
    	        var progressBar = document.getElementById("progress");
    	      
    	        xhr.addEventListener("progress", function(evt){
    	             if (evt.lengthComputable) {
    	               var percentComplete = evt.loaded / evt.total;
    	               //Do something with download progress
    	               console.log('evt.loaded ::: '+evt.loaded);
    	               console.log('evt.total ::: '+evt.total);
    	               //$('#download').show();
    	               	progressBar.max = evt.total;
   	                	progressBar.value = evt.loaded;
    	               console.log(percentComplete);
    	             }
    	             //return xhr;
    	        }, false);
    	        xhr.onloadstart = function(e) {
    	            progressBar.value = 0;
    	        };
    	        xhr.onloadend = function(e) {
    	            progressBar.value = e.loaded;
    	        };
    	        	
    	        return xhr;
    	     },
    	     
    	 });
    	
    	}, 1000);
}
    
    
    function dowload_ajax_submit2() {
    	
    	 // Ajax call for file uploaling
        var ajaxReq = $.ajax({
          url : '/api/s3/upload/download',
          type : 'POST',
         // data : formData,
          cache : false,
          contentType : false,
          processData : false,
          xhr: function(){
            //Get XmlHttpRequest object
             var xhr = $.ajaxSettings.xhr() ;
             var progressBar = document.getElementById("progress");
            
            //Set onprogress event handler 
             xhr.upload.onprogress = function(event){
              	var perc = Math.round((event.loaded / event.total) * 100);
              	console.log('perc :: '+perc);
              	$('#progressBar').text(perc + '%');
              	$('#progressBar').css('width',perc + '%');
              	progressBar.max = e.total;
            	progressBar.value = e.loaded;
             };
             return xhr ;
        	},
        	beforeSend: function( xhr ) {
        		//Reset alert message and progress bar
        		$('#alertMsg').text('');
        		$('#progressBar').text('');
        		$('#progressBar').css('width','0%');
            }
        });
      
        // Called on success of file upload
        ajaxReq.done(function(msg) {
          $('#alertMsg').text(msg);
          $('input[type=file]').val('');
         // $('button[type=submit]').prop('disabled',false);
        });
        
        // Called on failure of file upload
        ajaxReq.fail(function(jqXHR) {
          $('#alertMsg').text(jqXHR.responseText+'('+jqXHR.status+
          		' - '+jqXHR.statusText+')');
        //  $('button[type=submit]').prop('disabled',false);
        });
     // });
    	

}
    var interval = null;
    interval =setInterval(function(){ dowload_ajax_submit3(); }, 3000);
    function dowload_ajax_submit3() {

   	 
       var ajaxReq = $.ajax({
         url : 'downloadFileProgressPerCentage',
         type : 'POST',
        // data : formData,
         cache : false,
         contentType : false,
         processData : false,
         xhr: function(){
           //Get XmlHttpRequest object
            var xhr = $.ajaxSettings.xhr() ;
            var progressBar = document.getElementById("progress");
           
           //Set onprogress event handler 
            xhr.upload.onprogress = function(event){
             	var perc = Math.round((event.loaded / event.total) * 100);
             	console.log('perc :: '+perc);
             	$('#progressBar').text(perc + '%');
             	$('#progressBar').css('width',perc + '%');
             	progressBar.max = e.total;
           	progressBar.value = e.loaded;
            };
            return xhr ;
       	},
       	beforeSend: function( xhr ) {
       		//Reset alert message and progress bar
       		$('#alertMsg').text('');
       		$('#progressBar').text('');
       		$('#progressBar').css('width','0%');
           }
       });
     
       // Called on success of file upload
       ajaxReq.done(function(msg) {
    	   $.each(msg, function( index, value ) {
    		   if(value == 100){
    			   //clearInterval(interval);
    		   }
    		   $('#alertMsg').text(value);
    		   move(value);
    		   
    	});
         
         $('input[type=file]').val('');
        // $('button[type=submit]').prop('disabled',false);
       });
       
       // Called on failure of file upload
       ajaxReq.fail(function(jqXHR) {
         $('#alertMsg').text(jqXHR.responseText+'('+jqXHR.status+
         		' - '+jqXHR.statusText+')');
       //  $('button[type=submit]').prop('disabled',false);
       });
    // });
   	

}
    function move(value) {
  	  var elem = document.getElementById("myBar");
  	 //var progressBar = document.getElementById("progress");
  	  var width = value;
  	 // var id = setInterval(frame, 10);
  	  if (width == 100) {
  	      //clearInterval(id);
  		//elem.style.width = width + '%';
  		elem.max = 100;
  		elem.value = width;
  		clearInterval(interval);
  	    } else {
  	      //width++; 
  	      //elem.style.width = width + '%'; 
  	    	elem.max = 100;
  	    	elem.value = width;
  	    }
  	}
    var interval1 = null;
    //interval1 =setInterval(function(){ dowload_ajax_progressByte(); }, 3000);
    function dowload_ajax_progressByte() {

    	$.ajax({
    	    type: 'POST',
    	    url: "downloadFileProgress",
    	    //data: data.getProgress().getBytesTransferred(),
    	    success: function (data) {
    	    	$.each(data, function( index, value ) {
    	    		   if(value == 82694252){
    	    			   clearInterval(interval1);
    	    		   }
    	    		   move();
    	    		   //$('#alertMsg').text(value);
    	    		   
    	    	});
    	    },
    	    xhr: function(data){
    	    	//console.log("xhr call  "+this+" "+xhr);
    	        var xhr = new window.XMLHttpRequest();
    	        var progressBar = document.getElementById("progress");
    	       
    	       // alert('file download');
    	        xhr.addEventListener("progress", function(evt){
    	        	 console.log('file loaded: '+evt.loaded);
    	        	 console.log('file total: '+evt.total);
    	             if (evt.lengthComputable) {
    	               var percentComplete = evt.loaded / 82694252;
    	               //Do something with download progress
    	               console.log('evt.loaded ::: '+evt.loaded);
    	               console.log('evt.total ::: '+82694252);
    	               //$('#download').show();
    	               	progressBar.max = 82694252;////evt.total
   	                	progressBar.value = evt.loaded;
    	               console.log(percentComplete);
    	             }
    	             //return xhr;
    	        }, false);
    	        xhr.onloadstart = function(e) {
    	            progressBar.value = 0;
    	        };
    	        xhr.onloadend = function(e) {
    	            progressBar.value = e.loaded;
    	        };
    	        	
    	        return xhr;
    	     },
    	    
    	 });
    	

}
    
    
   