package com.mkyong.serviceimpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletContext;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.event.ProgressEvent;
import com.amazonaws.event.ProgressListener;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.services.s3.transfer.Download;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.Upload;
import com.mkyong.exception.MediaTypeUtils;
import com.mkyong.service.S3Services;

@Service
public class S3ServicesImpl implements S3Services{
	
	protected Logger logger = LoggerFactory.getLogger(S3ServicesImpl.class);
	Map<Integer,Long> map= null;
	Map<Integer,Long> mapBar= null;
	@Autowired
	protected TransferManager transferManager;

	@Value("${jsa.s3.bucket}")
	protected String bucketName;
	
	
	@Value("${jsa.s3.region}")
	private String region;

	@Autowired
	private ServletContext servletContext;
	  

	/**
	 * UPLOAD FILE to Amazon S3
	 */
	
	/**
	 * DOWNLOAD FILE from Amazon S3
	 */
	@Override
	public long downloadFile(String keyName, String downloadFilePath) {
		
		/*
		final GetObjectRequest request = new GetObjectRequest(bucketName, keyName);
		System.out.println("keyName ::: "+keyName);
		System.out.println("downloadFilePath ::: "+downloadFilePath);
		String str ="";
		request.setGeneralProgressListener(new ProgressListener() {
			@Override
			public void progressChanged(ProgressEvent progressEvent) {
				String transferredBytes = "Downloaded bytes: " + progressEvent.getBytesTransferred();
				System.out.println("transferredBytes :: "+transferredBytes);
				//logger.info(transferredBytes);
			}
		});
		//AmazonS3 s3 = AmazonS3ClientBuilder.defaultClient();
		//s3client().copyObject(bucketName, keyName, downloadFilePath, keyName);
		//Download download =null;
		Download download = transferManager.download(request, new File(downloadFilePath));
		return download;
		*/
		map=new HashMap<Integer,Long>();
		mapBar = new HashMap<Integer,Long>();
		String msg ="";
		long tsanferPercentage=0;
		long tsanferByte=0;
		final GetObjectRequest request = new GetObjectRequest(bucketName, keyName);
	    Download download = transferManager.download(request, new File(downloadFilePath));
	    
	    while (!download.isDone()) {
	        tsanferPercentage = (long) download.getProgress().getPercentTransferred();
	        tsanferByte = download.getProgress().getBytesTransferred();
	        mapBar.put(1, tsanferByte);
	        logger.info("Downloaded >> " + tsanferPercentage);
	        map.put(1, tsanferPercentage);
	       
	    }
	   
	   // return msg;
        
	    ProgressListener listener = progressEvent -> logger.info("Bytes transfer >> " + progressEvent.getBytesTransferred());

	    GetObjectRequest s3Request = new GetObjectRequest(bucketName, keyName);
	  
	    Download download1 = transferManager.download(s3Request, new File(downloadFilePath));
	   
	    download.addProgressListener(listener);
	    //return tsanferPercentage;
	    
	    try 
	    {
			download.waitForCompletion();
			//return tsanferPercentage;
		} catch (AmazonServiceException e) {
			//return tsanferPercentage;
			e.printStackTrace();
		} catch (AmazonClientException e) {
			//return tsanferPercentage;
			e.printStackTrace();
		} catch (InterruptedException e) {
			//return tsanferPercentage;
			e.printStackTrace();
		}
		//return tsanferPercentage;
		//return download.getProgress().getPercentTransferred();
	    logger.info("Downloaded 1 >> " + tsanferPercentage);
		return tsanferPercentage;
		
	}


	@Override
	public Map<Integer, Long> downloadProgress() {
		return map;
	}
	@Override
	public Map<Integer, Long> downloadProgressBar() {
		return mapBar;
	}

	/*@Override
	public void uploadFile1(String keyName,String uploadFilePath) {
		final PutObjectRequest request = new PutObjectRequest(bucketName, keyName, new File(uploadFilePath));
		//String bucketName = "baeldung-bucket";
		 
		if(s3client.doesBucketExist(bucketName)) {
		    System.out.println("Bucket name is not available."
		      + " Try again with a different Bucket name.");
		    return;
		}
		 
		//s3client.createBucket(bucketName);
		request.setGeneralProgressListener(new ProgressListener() {
			@Override
			public void progressChanged(ProgressEvent progressEvent) {
				String transferredBytes = "Uploaded bytes: " + progressEvent.getBytesTransferred();
				logger.info(transferredBytes);
			}
		});

		Upload upload = transferManager.upload(request);
		
		// Or you can block and wait for the upload to finish
		try {
			
			upload.waitForCompletion();
			
		} catch (AmazonServiceException e) {
			logger.info(e.getMessage());
		} catch (AmazonClientException e) {
			logger.info(e.getMessage());
		} catch (InterruptedException e) {
			logger.info(e.getMessage());
		}
	}*/
}
