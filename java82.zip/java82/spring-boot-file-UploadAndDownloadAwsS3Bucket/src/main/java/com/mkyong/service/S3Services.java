package com.mkyong.service;

import java.util.Map;

import com.amazonaws.services.s3.transfer.Download;

public interface S3Services {
	public long downloadFile(String keyName, String downloadFilePath);

	public Map<Integer, Long> downloadProgress();
	
	public Map<Integer, Long> downloadProgressBar();
}
