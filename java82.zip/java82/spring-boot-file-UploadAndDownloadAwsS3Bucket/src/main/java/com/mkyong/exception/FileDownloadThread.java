package com.mkyong.exception;

import com.amazonaws.services.s3.transfer.Download;

public class FileDownloadThread implements Runnable {
	public Download d;
	public FileDownloadThread(Download download) {
		
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

	

}
