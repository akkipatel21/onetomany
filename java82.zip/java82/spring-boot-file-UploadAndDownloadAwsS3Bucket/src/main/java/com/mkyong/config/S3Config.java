package com.mkyong.config;

import static com.amazonaws.services.s3.internal.Constants.MB;

import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import com.amazonaws.AmazonClientException;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.TransferManagerBuilder;
import com.amazonaws.services.sns.AmazonSNSClient;

@Configuration
public class S3Config {
	
	//@Value("${jsa.aws.access_key_id}")
	//private String awsId;

	//@Value("${jsa.aws.secret_access_key}")
	//private String awsKey;
	
	@Value("${jsa.s3.region}")
	private String region;
	
	@Value("${jsa.s3.bucket}")
	private String bucketName;
	
	private Logger logger = LoggerFactory.getLogger(S3Config.class);

	@Bean
	public AmazonS3 s3client() {
		//
		//BasicAWSCredentials awsCreds = new BasicAWSCredentials(awsId, awsKey);
		//AmazonSNSClient ansClient = new AmazonSNSClient(new DefaultAWSCredentialsProviderChain());
		AmazonS3 s3Client = AmazonS3ClientBuilder.standard()
								.withRegion(Regions.fromName(region))
		                        //.withCredentials(new AWSStaticCredentialsProvider(awsCreds))
		                        .build();
		
		return s3Client;
	}
	
	/*public Policy s3client() {
	Policy bucket_policy = new Policy().withStatements(
		    new Statement(Statement.Effect.Allow)
		        .withPrincipals(Principal.AllUsers)
		        .withActions(S3Actions.GetObject)
		        .withResources(new Resource(
		            "arn:aws:s3:::" + bucket_name + "/*")));
		return bucket_policy.toJson();
	}*/
	
	@Bean
	public TransferManager transferManager(){
		
		TransferManager tm = TransferManagerBuilder.standard()
									.withS3Client(s3client())
									.withDisableParallelDownloads(false)
									.withMinimumUploadPartSize(Long.valueOf(5 * MB))
									.withMultipartUploadThreshold(Long.valueOf(16 * MB))
									.withMultipartCopyPartSize(Long.valueOf(5 * MB))
									.withMultipartCopyThreshold(Long.valueOf(100 * MB))
									.withExecutorFactory(()->createExecutorService(20))
									.build();
		
		int oneDay = 1000 * 60 * 60 * 24;
		Date oneDayAgo = new Date(System.currentTimeMillis() - oneDay);
		
		try {
			
			tm.abortMultipartUploads(bucketName, oneDayAgo);
			
		} catch (AmazonClientException e) {
			logger.error("Unable to upload file, upload was aborted, reason: " + e.getMessage());
		}
		
		return tm;
	}
	
	 /*@Bean
	   public MultipartResolver multipartResolver() {
	      CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver();
	      multipartResolver.setMaxUploadSize(10485760); // 10MB
	      multipartResolver.setMaxUploadSizePerFile(1048576); // 1MB
	      return multipartResolver;
	   }*/

	
	private ThreadPoolExecutor createExecutorService(int threadNumber) {
        ThreadFactory threadFactory = new ThreadFactory() {
            private int threadCount = 1;

            public Thread newThread(Runnable r) {
                Thread thread = new Thread(r);
                thread.setName("jsa-amazon-s3-transfer-manager-worker-" + threadCount++);
                return thread;
            }
        };
        return (ThreadPoolExecutor)Executors.newFixedThreadPool(threadNumber, threadFactory);
    }
}
