package com.concretepage.dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.concretepage.entity.Article;
@Transactional
@Repository
public class ArticleDAO implements IArticleDAO {
	@PersistenceContext	
	private EntityManager entityManager;
	
	
	private EntityManager getEntityManager() {
		return entityManager;
	}
	@Override
	public Article getArticleById(int articleId) {
		return entityManager.find(Article.class, articleId);
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<Article> getAllArticles() {
		String hql = "FROM Article as atcl ORDER BY atcl.articleId";
		return (List<Article>) entityManager.createQuery(hql).getResultList();
	}	
	@Override
	public void addArticle(Article article) {
		System.out.println("article.getArticleId() "+article.getArticleId());
		System.out.println("article.getCategory() "+article.getCategory());
		System.out.println("article.getTitle() "+article.getTitle());
		/*entityManager.persist(article);
		//entityManager.
		entityManager.getTransaction().commit();
		entityManager.close();*/
		//EntityManager entityManager = JPAUtility.getEntityManager();
		//getEntityManager().persist(article);
		getEntityManager().merge(article);
		//entityManager.getTransaction().begin();
		//Employee employee = new Employee(1, "Mahesh", "Varanasi");
		//entityManager.persist(article);
		//entityManager.getTransaction().commit();
		//entityManager.close();
		//JPAUtility.close();
		//entityManager.
	}
	//@Override
	//@SuppressWarnings("unchecked")
	public void updateArticle(Article article,Integer id) {
		Article artcl = entityManager.find(Article.class, id);
		//Article artcl = getArticleById(article.getArticleId());
		artcl.setTitle(article.getTitle());
		artcl.setCategory(article.getCategory());
		entityManager.merge(artcl);
	}
	@Override
	public void deleteArticle(int articleId) {
		entityManager.remove(getArticleById(articleId));
	}
	@Override
	public boolean articleExists(String title, String category) {
		String hql = "FROM Article as atcl WHERE atcl.title = ? and atcl.category = ?";
		int count = entityManager.createQuery(hql).setParameter(1, title)
		              .setParameter(2, category).getResultList().size();
		return count > 0 ? true : false;
	}
}
