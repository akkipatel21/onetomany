package com.mkyoung.services;

import com.amazonaws.services.s3.transfer.Download;

public interface S3Services {
	//public void uploadFile(String keyName, String uploadFilePath);
	public void downloadFile(String keyName, String downloadFilePath);
	//public void uploadFile1(String keyName, String uploadFilePath);
}
