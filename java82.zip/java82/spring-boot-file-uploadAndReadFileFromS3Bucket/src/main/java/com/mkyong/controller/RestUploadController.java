package com.mkyong.controller;

import com.amazonaws.event.ProgressEvent;
import com.amazonaws.event.ProgressEventType;
import com.amazonaws.event.ProgressListener;
import com.amazonaws.services.s3.transfer.Download;
import com.amazonaws.services.s3.transfer.Transfer;
import com.mkyong.model.UploadModel;
import com.mkyoung.services.S3Services;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;

@RestController
public class RestUploadController {

    private final Logger logger = LoggerFactory.getLogger(RestUploadController.class);

    //Save the uploaded file to this folder
    private static String UPLOADED_FOLDER = "C:/Users/pratikj/Desktop/spring-boot-master/";
    @Autowired
	S3Services s3Services;
	
	@Value("${jsa.s3.uploadfile}")
	private String uploadFilePath;
	
	@Value("${jsa.s3.downloadfile}")
	private String downloadFilePath;
	
	@Value("${jsa.s3.key}")
	private String key;
    //Single file upload
    @PostMapping("/api/upload")
    // If not @RestController, uncomment this
    //@ResponseBody
    public ResponseEntity<?> uploadFile(
            @RequestParam("file") MultipartFile uploadfile) {

        logger.debug("Single file upload!");

        if (uploadfile.isEmpty()) {
            return new ResponseEntity("please select a file!", HttpStatus.OK);
        }

        try {

            saveUploadedFiles(Arrays.asList(uploadfile));

        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        return new ResponseEntity("Successfully uploaded - " +
                uploadfile.getOriginalFilename(), new HttpHeaders(), HttpStatus.OK);

    }

    // Multiple file upload
    @PostMapping("/api/upload/multi")
    public ResponseEntity<?> uploadFileMulti(
            @RequestParam("extraField") String extraField,
            @RequestParam("files") MultipartFile[] uploadfiles) throws IOException {

        logger.debug("Multiple file upload!");
        System.out.println("extraField "+extraField);
        System.out.println("uploadfiles "+uploadfiles);
        String uploadedFileName = Arrays.stream(uploadfiles).map(x -> x.getOriginalFilename())
                .filter(x -> !StringUtils.isEmpty(x)).collect(Collectors.joining(" , "));
        /*URL url = new URL("file:///C:/Users/pratikj/Desktop/spring-boot-master/myjson.json");
       try (InputStream is = url.openStream();
              JsonReader rdr = Json.createReader(is)) {
        
             JsonObject obj = rdr.readObject();
             JsonArray results = obj.getJsonArray("data");
             for (JsonObject result : results.getValuesAs(JsonObject.class)) {
                 //System.out.print(result.getJsonObject("from").getString("name"));
            	 System.out.print(result.getJsonObject("id").toString());
                 System.out.print(result.getJsonObject("id").getString("id"));
                 System.out.print(": ");
                //System.out.println(result.getString("message", ""));
                System.out.println("-----------");
            }
        }*/
        if (StringUtils.isEmpty(uploadedFileName)) {
            return new ResponseEntity("please select a file!", HttpStatus.OK);
        }
        JSONParser parser = new JSONParser();
        try {

            saveUploadedFiles(Arrays.asList(uploadfiles));
            Object obj = parser.parse(new FileReader(
                    "C:/Users/pratikj/Desktop/spring-boot-master/file1.txt"));
            
            JSONObject jsonObject = (JSONObject) obj;
            
            String name = (String) jsonObject.get("Name");
            String author = (String) jsonObject.get("Author");
            JSONArray companyList = (JSONArray) jsonObject.get("Company List");
 
            System.out.println("Name: " + name);
            System.out.println("Author: " + author);
            System.out.println("\nCompany List:");
            Iterator<String> iterator = companyList.iterator();
            while (iterator.hasNext()) {
                System.out.println(iterator.next());
            }
            
            Object obj1 = parser.parse(new FileReader(
                    "C:/Users/pratikj/Desktop/spring-boot-master/file1.json"));
            
            JSONObject jsonObject1 = (JSONObject) obj1;
            
            String name1 = (String) jsonObject1.get("Name");
            String author1 = (String) jsonObject1.get("Author");
            JSONArray companyList1 = (JSONArray) jsonObject1.get("Company List");
 
            System.out.println("Name: " + name);
            System.out.println("Author: " + author);
            System.out.println("\nCompany List:");
            Iterator<String> iterator1 = companyList1.iterator();
            while (iterator1.hasNext()) {
                System.out.println(iterator1.next());
            }

        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return new ResponseEntity("Successfully uploaded - "
                + uploadedFileName, HttpStatus.OK);

    }
    
 // Multiple file upload
    @PostMapping("/api/upload/downloadS3Bucket")
    public void downloadS3Bucket(
           // @RequestParam("extraField") String extraField,
          //  @RequestParam("files") MultipartFile[] uploadfiles
            ) throws IOException {

        logger.debug("Multiple file upload!");
       
        System.out.println("---------------- START DOWNLOAD FILE ----------------");
		s3Services.downloadFile(key, downloadFilePath);
		System.out.println("DONE!");

        //return d;

    }
    
   /* @PostMapping("/api/upload/progressBar")
    public ProgressListener progressBar(
           // @RequestParam("extraField") String extraField,
          @RequestParam("Transfer") Transfer transfer
            ) throws IOException {
    	
        
		System.out.println("DONE!");

        return new ProgressListener() {
        	public ProgressEventType previousType;
        	public double previousTransferred;
        	@Override
        	public synchronized void progressChanged(ProgressEvent progressEvent) {
        		ProgressEventType eventType =progressEvent.getEventType();
        		if(previousType != eventType) {
        			previousType =eventType;
        		}
        		double transferred=transfer.getProgress().getPercentTransfered();
        		if(transferred >= (previousTransferred+10.0)) {
        			previousTransferred =transferred;
        		}
        	}
        };

    }*/
    

    // maps html form to a Model
    @PostMapping("/api/upload/multi/model")
    public ResponseEntity<?> multiUploadFileModel(@ModelAttribute UploadModel model) {

        logger.debug("Multiple file upload! With UploadModel");

        try {

            saveUploadedFiles(Arrays.asList(model.getFiles()));

        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        return new ResponseEntity("Successfully uploaded!", HttpStatus.OK);

    }

    //save file
    private void saveUploadedFiles(List<MultipartFile> files) throws IOException {

        for (MultipartFile file : files) {

            if (file.isEmpty()) {
                continue; //next pls
            }

            byte[] bytes = file.getBytes();
            Path path = Paths.get(UPLOADED_FOLDER + file.getOriginalFilename());
            Files.write(path, bytes);

        }

    }
}
