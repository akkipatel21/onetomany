package pl.dmichalski.reservations.business.time;

import java.util.Date;

public interface CurrentTimeService {

    Date getCurrentDate();

}
