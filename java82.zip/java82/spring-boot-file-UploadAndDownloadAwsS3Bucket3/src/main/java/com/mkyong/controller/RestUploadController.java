package com.mkyong.controller;


import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.transfer.Download;
import com.mkyong.exception.MediaTypeUtils;
import com.mkyong.model.UploadModel;
import com.mkyong.service.S3Services;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;


//new 
import javax.servlet.Servlet;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import java.io.*;
import java.util.*;
import javax.servlet.http.*;
import org.apache.commons.fileupload.*;
import javax.servlet.ServletException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

@RestController
public class RestUploadController {

    private final Logger logger = LoggerFactory.getLogger(RestUploadController.class);

    //Save the uploaded file to this folder
    private static String UPLOADED_FOLDER = "C:/Users/pratikj/Desktop/spring-boot-master/";
    
    @Autowired
	S3Services s3Services;
	
	@Value("${jsa.s3.uploadfile}")
	private String uploadFilePath;
	
	@Value("${jsa.s3.downloadfile}")
	private String downloadFilePath;
	
	private static final String DIRECTORY = "C:\\Users\\pratikj\\resources\\upload";
    private static final String DEFAULT_FILE_NAME = "file1.json";//C:\\Users\\pratikj\\resources\\download\\51.zip
 
    @Autowired
    private ServletContext servletContext;
 
	
	@Value("${jsa.s3.key}")
	private String key;
    
    //Single file upload
    @PostMapping("/api/upload")
    // If not @RestController, uncomment this
    //@ResponseBody
    public ResponseEntity<?> uploadFile(
            @RequestParam("file") MultipartFile uploadfile) {

        logger.debug("Single file upload!");

        if (uploadfile.isEmpty()) {
            return new ResponseEntity("please select a file!", HttpStatus.OK);
        }

        try {

            saveUploadedFiles(Arrays.asList(uploadfile));

        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        return new ResponseEntity("Successfully uploaded - " +
                uploadfile.getOriginalFilename(), new HttpHeaders(), HttpStatus.OK);

    }

    // Multiple file upload
    @PostMapping("/api/upload/multi")
    public ResponseEntity<?> uploadFileMulti(
            @RequestParam("extraField") String extraField,
            @RequestParam("files") MultipartFile uploadfiles) throws IOException {

        logger.debug("Multiple file upload!");
        System.out.println("extraField "+extraField);
        System.out.println("uploadfiles "+uploadfiles);
        
        String myString = uploadfiles.getName();
        /*InputStream in = uploadfiles.getInputStream();
    	char read = 0;
    	byte[] bytes = new byte[1024];
    	while((read = (char) in.read(bytes)) != -1) {
    		myString += read;
    	}*/
    	
       File f = convert(uploadfiles);
        
        /*String uploadedFileName = Arrays.stream(uploadfiles).map(x -> x.getOriginalFilename())
                .filter(x -> !StringUtils.isEmpty(x)).collect(Collectors.joining(" , "));*/
       
        if (StringUtils.isEmpty(uploadfiles.getName())) {
            return new ResponseEntity("please select a file!", HttpStatus.OK);
        }
        JSONParser parser = new JSONParser();
        try {
        	
        	
        	if (!uploadfiles.isEmpty()) {

        		 Object obj = parser.parse(new FileReader(f));
        		// Object obj = parser.parse(new FileReader(uploadfiles.getOriginalFilename()));
                 System.out.println("obj :: "+obj);
                 JSONObject jsonObject = (JSONObject) obj;
                 
                 String name = (String) jsonObject.get("Name");
                 String author = (String) jsonObject.get("Author");
                 JSONArray companyList = (JSONArray) jsonObject.get("Company List");
      
                 System.out.println("Name: " + name);
                 System.out.println("Author: " + author);
                 System.out.println("\nCompany List:");
                 Iterator<String> iterator = companyList.iterator();
                 while (iterator.hasNext()) {
                     System.out.println(iterator.next());
                 } 

            } 
        	
           

        } catch (Exception e) {
            e.printStackTrace();
        }

        return new ResponseEntity("Successfully uploaded - "
                + myString, HttpStatus.OK);

    }
    @PostMapping("/api/s3/upload/multi")
    public ResponseEntity<?> uploadS3FileMulti(
            @RequestParam("extraField") String extraField,
            @RequestParam("files") MultipartFile uploadfiles) throws IOException {

        logger.debug("Multiple file upload!");
        System.out.println("extraField "+extraField);
        System.out.println("uploadfiles "+uploadfiles);
        
        String myString = uploadfiles.getName();
        
    	
       File f = convert(uploadfiles);
        
        /*String uploadedFileName = Arrays.stream(uploadfiles).map(x -> x.getOriginalFilename())
                .filter(x -> !StringUtils.isEmpty(x)).collect(Collectors.joining(" , "));*/
       
        if (StringUtils.isEmpty(uploadfiles.getName())) {
            return new ResponseEntity("please select a file!", HttpStatus.OK);
        }
        JSONParser parser = new JSONParser();
        try {
        	
        	
        	if (!uploadfiles.isEmpty()) {

        		 Object obj = parser.parse(new FileReader(f));
        		// Object obj = parser.parse(new FileReader(uploadfiles.getOriginalFilename()));
                 System.out.println("obj :: "+obj);
                 JSONObject jsonObject = (JSONObject) obj;
                 
                 String name = (String) jsonObject.get("Name");
                 String author = (String) jsonObject.get("Author");
                 JSONArray companyList = (JSONArray) jsonObject.get("Company List");
      
                 System.out.println("Name: " + name);
                 System.out.println("Author: " + author);
                 System.out.println("\nCompany List:");
                 Iterator<String> iterator = companyList.iterator();
                 while (iterator.hasNext()) {
                     System.out.println(iterator.next());
                 } 

            } 
        	
           

        } catch (Exception e) {
            e.printStackTrace();
        }

        return new ResponseEntity("Successfully uploaded - "
                + myString, HttpStatus.OK);

    }
    
    @PostMapping("/api/s3/upload/download")
    public Download downloadS3FileMulti(
           // @RequestParam("extraField") String extraField,
           // @RequestParam("files") MultipartFile uploadfiles
            ) throws IOException {
    	Date d = new Date();
    	String str ="";
        logger.debug("Multiple file upload!");
        System.out.println("---------------- START DOWNLOAD FILE ----------------");
        Download download =s3Services.downloadFile(key, downloadFilePath);
        System.out.println("sr.getProgress().getTotalBytesToTransfer() :: "+download.getProgress().getTotalBytesToTransfer()+" time ::"+d);
        try {
			str ="success";
			download.waitForCompletion();
			
		} catch (AmazonServiceException e) {
			str ="fail";
			logger.info(e.getMessage());
		} catch (AmazonClientException e) {
			str ="fail";
			logger.info(e.getMessage());
		} catch (InterruptedException e) {
			str ="fail";
			logger.info(e.getMessage());
		}
		System.out.println("DONE!");
		System.out.println("sr.getProgress().getTotalBytesToTransfer() 2 :: "+download.getProgress().getTotalBytesToTransfer()+" time ::"+d);

        return download;

    }
    //downloadFileProgress
    @PostMapping("/downloadFileProgress")
    public Download downloadFileProgress(
           // @RequestParam("extraField") String extraField,
           // @RequestParam("files") MultipartFile uploadfiles
            ) throws IOException {
    	Date d = new Date();
    	String str ="";
        logger.debug("Multiple file upload!");
        System.out.println("---------------- START DOWNLOAD FILE ----------------");
        Download download =s3Services.downloadFile(key, downloadFilePath);
        System.out.println("sr.getProgress().getTotalBytesToTransfer() :: "+download.getProgress().getTotalBytesToTransfer()+" time ::"+d);
        try {
			str ="success";
			download.waitForCompletion();
			
		} catch (AmazonServiceException e) {
			str ="fail";
			logger.info(e.getMessage());
		} catch (AmazonClientException e) {
			str ="fail";
			logger.info(e.getMessage());
		} catch (InterruptedException e) {
			str ="fail";
			logger.info(e.getMessage());
		}
		System.out.println("DONE!");
		System.out.println("sr.getProgress().getTotalBytesToTransfer() 2 :: "+download.getProgress().getTotalBytesToTransfer()+" time ::"+d);

        return download;

    }
    //@PostMapping("/download1")
    @GetMapping("/download1")
    public ResponseEntity<InputStreamResource> downloadS3FileMulti2(
           // @RequestParam("extraField") String extraField,
           // @RequestParam("files") MultipartFile uploadfiles
            ) throws IOException {

    	String sr ="";
    	
    	MediaType mediaType = MediaTypeUtils.getMediaTypeForFileName(this.servletContext, DEFAULT_FILE_NAME);
        System.out.println("fileName: " + DEFAULT_FILE_NAME);
        System.out.println("mediaType: " + mediaType);
 
        File file = new File(DIRECTORY + "/" + DEFAULT_FILE_NAME);
        InputStreamResource resource = new InputStreamResource(new FileInputStream(file));
 
        return ResponseEntity.ok()
                // Content-Disposition
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + file.getName())
                // Content-Type
                .contentType(mediaType)
                // Contet-Length
                .contentLength(file.length()) //
                .body(resource);
    }
    @GetMapping("/download2")
    public ResponseEntity<ByteArrayResource> download2(
           // @RequestParam("extraField") String extraField,
           // @RequestParam("files") MultipartFile uploadfiles
            ) throws IOException {

    	MediaType mediaType = MediaTypeUtils.getMediaTypeForFileName(this.servletContext, DEFAULT_FILE_NAME);
        System.out.println("fileName: " + DEFAULT_FILE_NAME);
        System.out.println("mediaType: " + mediaType);
 
        Path path = Paths.get(DIRECTORY + "/" + DEFAULT_FILE_NAME);
        byte[] data = Files.readAllBytes(path);
        ByteArrayResource resource = new ByteArrayResource(data);
 
        return ResponseEntity.ok()
                // Content-Disposition
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + path.getFileName().toString())
                // Content-Type
                .contentType(mediaType) //
                // Content-Lengh
                .contentLength(data.length) //
                .body(resource);
    }
    
    @GetMapping("/download3")
    public void download3(HttpServletResponse resonse
           // @RequestParam("extraField") String extraField,
           // @RequestParam("files") MultipartFile uploadfiles
            ) throws IOException {

    	MediaType mediaType = MediaTypeUtils.getMediaTypeForFileName(this.servletContext, DEFAULT_FILE_NAME);
        System.out.println("fileName: " + DEFAULT_FILE_NAME);
        System.out.println("mediaType: " + mediaType);
 
        File file = new File(DIRECTORY + "/" + DEFAULT_FILE_NAME);
 
        // Content-Type
        // application/pdf
        resonse.setContentType(mediaType.getType());
 
        // Content-Disposition
        resonse.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + file.getName());
 
        // Content-Length
        resonse.setContentLength((int) file.length());
 
        BufferedInputStream inStream = new BufferedInputStream(new FileInputStream(file));
        BufferedOutputStream outStream = new BufferedOutputStream(resonse.getOutputStream());
 
        byte[] buffer = new byte[1024];
        int bytesRead = 0;
        while ((bytesRead = inStream.read(buffer)) != -1) {
            outStream.write(buffer, 0, bytesRead);
        }
        outStream.flush();
        inStream.close();
		//return null;
    }
    public static File convert(MultipartFile file) throws IOException {
        File convFile = new File(file.getOriginalFilename());
        convFile.createNewFile();
        FileOutputStream fos = new FileOutputStream(convFile);
        fos.write(file.getBytes());
        fos.close();
        return convFile;
    }

    // maps html form to a Model
    @PostMapping("/api/upload/multi/model")
    public ResponseEntity<?> multiUploadFileModel(@ModelAttribute UploadModel model) {

        logger.debug("Multiple file upload! With UploadModel");

        try {

            saveUploadedFiles(Arrays.asList(model.getFiles()));

        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        return new ResponseEntity("Successfully uploaded!", HttpStatus.OK);

    }

    //save file
    private void saveUploadedFiles(List<MultipartFile> files) throws IOException {

        for (MultipartFile file : files) {

            if (file.isEmpty()) {
                continue; //next pls
            }

            byte[] bytes = file.getBytes();
            Path path = Paths.get(UPLOADED_FOLDER + file.getOriginalFilename());
            Files.write(path, bytes);

        }

    }
}
