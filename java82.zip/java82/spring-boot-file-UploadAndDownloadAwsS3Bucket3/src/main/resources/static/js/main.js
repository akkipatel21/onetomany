var progressBarValue=0;
$(document).ready(function () {
	//$( "#progressbar" ).progressbar({             value:0         });
	//document.getElementById("progressbarWrapper").style.display = "none";
    $("#btnSubmit").click(function (event) {

        //stop submit the form, we will post it manually.
        event.preventDefault();

        //fire_ajax_submit();
        ///api/s3/upload/multi
        fire_ajax_submit1();
    });

});
function updateProgressBar(progressBarValue)
{
	$("#progressbar").progressbar("option","value",progressBarValue);
}
var req;

function ajaxFunction(){
	var url = "/api/s3/upload/download";
    
    if (window.XMLHttpRequest){ 
		req = new XMLHttpRequest();
        try{
			req.onreadystatechange = funcReadyStateChange;
            req.open("POST", url, true);
        } catch (e) {
			alert(e);
        }
        req.send(null);
    }

    else if (window.ActiveXObject) { 
		req = new ActiveXObject("Microsoft.XMLHTTP");
        if (req) {
			req.onreadystatechange = funcReadyStateChange;
            req.open("GET", url, true);
            req.send();
        }
    }
}
     
function funcReadyStateChange(){
	if (req.readyState == 4){
		if (req.status == 200){
			var xml = req.responseXML;
			var responseNode=xml.getElementsByTagName("response")[0];
			var noOfBytesRead =responseNode.getElementsByTagName("bytes_read")[0].
				childNodes[0].nodeValue;
			var totalNoOfBytes = responseNode.getElementsByTagName("content_length")[0].
				childNodes[0].nodeValue;
			progressBarValue=noOfBytesRead/totalNoOfBytes*100;             
			document.getElementById("status").style.display="block";
			document.getElementById("percentDone").innerHTML="Percentage Completed: "
				+Math.floor(progressBarValue)+"%";
			document.getElementById("bytesRead").innerHTML= "Number Of Bytes Read: "+
				noOfBytesRead;
			document.getElementById("totalNoOfBytes").innerHTML= "Total Number Of Bytes: "+
				totalNoOfBytes;
			document.getElementById("progressbarWrapper").style.display = "block";
                
            if (progressBarValue<100){
				window.setTimeout("ajaxFunction();", 100);
                window.setTimeout("updateProgressBar(progressBarValue);", 100);
                   
            } else {
                alert("Done");
                window.setTimeout("updateProgressBar(100);", 100);
                document.getElementById("progressbarWrapper").style.display = "none";
                document.getElementById("status").style.display="none";
            }
		} else {
			alert(req.statusText);
		}
    }
}

function fire_ajax_submit() {

    // Get form
    var form = $('#fileUploadForm')[0];

    var data = new FormData(form);

    data.append("CustomField", "This is some extra data, testing");

    $("#btnSubmit").prop("disabled", true);

    $.ajax({
        type: "POST",
        enctype: 'multipart/form-data',
        url: "/api/upload/multi",
        data: data,
        //http://api.jquery.com/jQuery.ajax/
        //https://developer.mozilla.org/en-US/docs/Web/API/FormData/Using_FormData_Objects
        processData: false, //prevent jQuery from automatically transforming the data into a query string
        contentType: false,
        cache: false,
        timeout: 600000,
        success: function (data) {

            $("#result").text(data);
            console.log("SUCCESS : ", data);
            $("#btnSubmit").prop("disabled", false);

        },
        error: function (e) {

            $("#result").text(e.responseText);
            console.log("ERROR : ", e);
            $("#btnSubmit").prop("disabled", false);

        }
    });

}
function fire_ajax_submit1() {

    // Get form
    var form = $('#fileUploadForm')[0];

    var data = new FormData(form);

    data.append("CustomField", "This is some extra data, testing");

    $("#btnSubmit").prop("disabled", true);

    $.ajax({
        type: "POST",
        enctype: 'multipart/form-data',
        url: "/api/s3/upload/multi",
        data: data,
        processData: false,
        contentType: false,
        cache: false,
        timeout: 600000,
        success: function (data) {

            $("#result").text(data);
            console.log("SUCCESS : ", data);
            $("#btnSubmit").prop("disabled", false);
            dowload_ajax_submit2();
           // downloadFile();

        },
        error: function (e) {

            $("#result").text(e.responseText);
            console.log("ERROR : ", e);
            $("#btnSubmit").prop("disabled", false);

        }
    });
} 
    
    /*function dowload_ajax_submit1() {

    	$.ajax({
    	    type: 'POST',
    	    url: "/api/s3/upload/download",
    	    //data: {},
    	    beforeSend: function(XMLHttpRequest){
    	       
    	        //Download progress
    	        XMLHttpRequest.addEventListener("progress", function(evt){
    	            if (evt.lengthComputable) {  
    	                var percentComplete = evt.loaded / evt.total;
    	                //Do something with download progress
    	                console.log("percentComplete :: "+percentComplete)
    	            }
    	        }, false); 
    	    },
    	    success: function(data){
    	        //Do something success-ish
    	    	console.log("data"+data);
    	    }
    	});
    	

}*/
/*function progress() {
    var val = progressbar.progressbar( "value" ) || 0;

    progressbar.progressbar( "value", val + 2 );

    if ( val < 99 ) {
      setTimeout( progress, 80 );
    }
  }*/

  //setTimeout( progress, 2000 );
//} );
    
    function dowload_ajax_submit1() {

    	$.ajax({
    	    type: 'POST',
    	    url: "/api/s3/upload/download",
    	    //data: {},
    	    xhr: function(){
    	    	//console.log("xhr call  "+this+" "+xhr);
    	        var xhr = new window.XMLHttpRequest();
    	        var progressBar = document.getElementById("progress");
    	        xhr.responseType = "arraybuffer";
    	        xhr.onprogress = function(e) {
    	            if (e.lengthComputable) {
    	                progressBar.max = e.total;
    	                progressBar.value = e.loaded;
    	            	console.log(e.total+" "+e.total);
    	            }
    	        };
    	        xhr.onloadstart = function(e) {
    	            progressBar.value = 0;
    	        };
    	        xhr.onloadend = function(e) {
    	            progressBar.value = e.loaded;
    	        };
    	        /*xhr.addEventListener("progress", function(evt){
    	             if (evt.lengthComputable) {
    	               var percentComplete = evt.loaded / evt.total;
    	               //Do something with download progress
    	               console.log('evt.loaded ::: '+evt.loaded);
    	               console.log('evt.total ::: '+evt.total);
    	               $('#download').show();
    	               	progressBar.max = evt.total;
   	                	progressBar.value = evt.loaded;
    	               console.log(percentComplete);
    	             }
    	             //return xhr;
    	        }, false);
    	        xhr.onloadstart = function(e) {
    	            progressBar.value = 0;
    	        };
    	        xhr.onloadend = function(e) {
    	            progressBar.value = e.loaded;
    	        };*/
    	        	
    	        return xhr;
    	     },
    	     /*complete:function(){
    	         console.log("Request finished.");
    	         $('#download').hide();
    	     }*/
    	        /*xhr.onprogress = function(e) {
    	            if (e.lengthComputable) {
    	                progressBar.max = e.total;
    	                progressBar.value = e.loaded;
    	            }
    	        };
    	        xhr.onloadstart = function(e) {
    	            progressBar.value = 0;
    	        };
    	        xhr.onloadend = function(e) {
    	            progressBar.value = e.loaded;
    	        };
    	        xhr.send(null);
    	 }*/
    	 });
    	

}
    
    
    function dowload_ajax_submit2() {

    	 // Ajax call for file uploaling
        var ajaxReq = $.ajax({
          url : '/api/s3/upload/download',
          type : 'POST',
         // data : formData,
          cache : false,
          contentType : false,
          processData : false,
          xhr: function(){
            //Get XmlHttpRequest object
             var xhr = $.ajaxSettings.xhr() ;
             var progressBar = document.getElementById("progress");
            
            //Set onprogress event handler 
             xhr.upload.onprogress = function(event){
              	var perc = Math.round((event.loaded / event.total) * 100);
              	console.log('perc :: '+perc);
              	$('#progressBar').text(perc + '%');
              	$('#progressBar').css('width',perc + '%');
              	progressBar.max = e.total;
            	progressBar.value = e.loaded;
             };
             return xhr ;
        	},
        	beforeSend: function( xhr ) {
        		//Reset alert message and progress bar
        		$('#alertMsg').text('');
        		$('#progressBar').text('');
        		$('#progressBar').css('width','0%');
            }
        });
      
        // Called on success of file upload
        ajaxReq.done(function(msg) {
          $('#alertMsg').text(msg);
          $('input[type=file]').val('');
         // $('button[type=submit]').prop('disabled',false);
        });
        
        // Called on failure of file upload
        ajaxReq.fail(function(jqXHR) {
          $('#alertMsg').text(jqXHR.responseText+'('+jqXHR.status+
          		' - '+jqXHR.statusText+')');
        //  $('button[type=submit]').prop('disabled',false);
        });
     // });
    	

}
    function downloadFile(){
    	var xhr = new XMLHttpRequest();
    	var progressBar = document.getElementById("progress");
    	xhr.open("GET", "/api/s3/upload/download" +Math.floor(Math.random() * 99999), true);
    	xhr.onprogress = function (e) {
    	   /* if (e.lengthComputable) {*/
    	        console.log(e.loaded+  " / " + e.total)
    	    	progressBar.max = e.total;
            	progressBar.value = e.loaded;
            	console.log('progressBar ::: '+progressBar.value);
           // console.log(percentComplete);
    	   /* }*/
    	}
    	xhr.onloadstart = function (e) {
    	    console.log("start")
    	}
    	xhr.onloadend = function (e) {
    	    console.log("end")
    	}
    	xhr.send();
    }