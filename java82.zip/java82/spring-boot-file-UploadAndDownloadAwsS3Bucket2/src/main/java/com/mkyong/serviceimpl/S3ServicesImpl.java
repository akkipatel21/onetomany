package com.mkyong.serviceimpl;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.event.ProgressEvent;
import com.amazonaws.event.ProgressListener;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.transfer.Download;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.Upload;
import com.mkyong.service.S3Services;

@Service
public class S3ServicesImpl implements S3Services{
	
	protected Logger logger = LoggerFactory.getLogger(S3ServicesImpl.class);
	
	@Autowired
	protected TransferManager transferManager;

	@Value("${jsa.s3.bucket}")
	protected String bucketName;

	/**
	 * UPLOAD FILE to Amazon S3
	 */
	
	/**
	 * DOWNLOAD FILE from Amazon S3
	 */
	@Override
	public Download downloadFile(String keyName, String downloadFilePath) {
		final GetObjectRequest request = new GetObjectRequest(bucketName, keyName);
		System.out.println("keyName ::: "+keyName);
		System.out.println("downloadFilePath ::: "+downloadFilePath);
		String str ="";
		request.setGeneralProgressListener(new ProgressListener() {
			@Override
			public void progressChanged(ProgressEvent progressEvent) {
				String transferredBytes = "Downloaded bytes: " + progressEvent.getBytesTransferred();
				//System.out.println("transferredBytes :: "+transferredBytes);
				//logger.info(transferredBytes);
			}
		});
		
		Download download = transferManager.download(request, new File(downloadFilePath));
		return download;
		
		//return
		
	}

	/*@Override
	public void uploadFile1(String keyName,String uploadFilePath) {
		final PutObjectRequest request = new PutObjectRequest(bucketName, keyName, new File(uploadFilePath));
		//String bucketName = "baeldung-bucket";
		 
		if(s3client.doesBucketExist(bucketName)) {
		    System.out.println("Bucket name is not available."
		      + " Try again with a different Bucket name.");
		    return;
		}
		 
		//s3client.createBucket(bucketName);
		request.setGeneralProgressListener(new ProgressListener() {
			@Override
			public void progressChanged(ProgressEvent progressEvent) {
				String transferredBytes = "Uploaded bytes: " + progressEvent.getBytesTransferred();
				logger.info(transferredBytes);
			}
		});

		Upload upload = transferManager.upload(request);
		
		// Or you can block and wait for the upload to finish
		try {
			
			upload.waitForCompletion();
			
		} catch (AmazonServiceException e) {
			logger.info(e.getMessage());
		} catch (AmazonClientException e) {
			logger.info(e.getMessage());
		} catch (InterruptedException e) {
			logger.info(e.getMessage());
		}
	}*/
}
