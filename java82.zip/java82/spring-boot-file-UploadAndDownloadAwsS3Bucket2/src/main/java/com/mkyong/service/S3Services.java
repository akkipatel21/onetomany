package com.mkyong.service;

import com.amazonaws.services.s3.transfer.Download;

public interface S3Services {
	public Download downloadFile(String keyName, String downloadFilePath);
}
