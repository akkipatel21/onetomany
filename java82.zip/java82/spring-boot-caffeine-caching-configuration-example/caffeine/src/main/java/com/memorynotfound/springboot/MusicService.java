package com.memorynotfound.springboot;

public interface MusicService {

    String play(final String instrument);
}

