Spring MVC Embedded Jetty Example
=================================

Basic Spring MVC 4 application using embedded Jetty 9 server. No-xml configuration.

Includes API REST service, Freemarker and JSP examples.

Integration with Mongo DB.


Requirements
------------
* [Java Platform (JDK) 8](http://www.oracle.com/technetwork/java/javase/downloads/index.html)
* [Apache Maven 3.x](http://maven.apache.org/)
